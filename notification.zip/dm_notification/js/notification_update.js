/**
 * @file
 * Update notification count.
 */

 (function ($) {
  'use strict';

  const params = new URLSearchParams(window.location.search)
  if (
    params.has('open_settings') &&
    params.get('open_settings') == 1
  ) {
    $('.toolbox__section_notification_center .mark-all-read').addClass('uk-hidden');
  }

  function showNotificationCount() {
    if (
      typeof drupalSettings.unreadNotificationCount === 'undefined' ||
      drupalSettings.unreadNotificationCount == ''
    ) {
      $('#notification-count').addClass('uk-hidden');
      $('.mark-all-read').addClass('uk-hidden');
    }
    else {
      $('#notification-count').addClass('uk-visible');
      $('#notification-count').removeClass('uk-hidden');
      $('.mark-all-read').addClass('uk-visible');
      $('.mark-all-read').removeClass('uk-hidden');
      $('#notification-count').text(drupalSettings.unreadNotificationCount);
    }
  }
  
  function hideNotificationEmptyMessage() {
    if ($('.view-display-id-attachment_1 .view-content').length > 0) {
      $('#notification_center .view-notifications .view-empty').hide();
    }
    else {
      $('#notification_center .view-notifications .view-empty').show();
    }
  }


  Drupal.behaviors.notificationUpdate = {
    attach: function (context, settings) {
      hideNotificationEmptyMessage();
      showNotificationCount();
      if (
        typeof UIkit.util == 'object' &&
        $('.toolbox__section_notification_center').length == 1
      ) {
        UIkit.util.on('.notification-tab .notification-list-tab', 'click', function() {
          UIkit.switcher('#notification-tab-ul').show(0);
          if (drupalSettings.unreadNotificationCount != '') {
            $('.toolbox__section_notification_center .mark-all-read').removeClass('uk-hidden');
          }
        });
        UIkit.util.on('.notification-tab .notification-settings-tab', 'click', function() {
          UIkit.switcher('#notification-tab-ul').show(1);
          $('.toolbox__section_notification_center .mark-all-read').addClass('uk-hidden');
        });
      }
    }
  }

})(jQuery);

<?php

namespace Drupal\dm_notification_settings\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting User Notification Settings entities.
 *
 * @ingroup dm_notification_settings
 */
class NotificationSettingEntityDeleteForm extends ContentEntityDeleteForm {


}

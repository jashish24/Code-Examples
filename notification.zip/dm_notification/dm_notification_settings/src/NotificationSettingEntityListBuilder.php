<?php

namespace Drupal\dm_notification_settings;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityListBuilder;
use Drupal\Core\Link;

/**
 * Defines a class to build a listing of User Notification Settings entities.
 *
 * @ingroup dm_notification_settings
 */
class NotificationSettingEntityListBuilder extends EntityListBuilder {

  /**
   * {@inheritdoc}
   */
  public function buildHeader() {
    $header = [];
    $header['id'] = $this->t('User Notification Settings ID');
    $header['name'] = $this->t('Name');
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    $row = [];
    /** @var \Drupal\dm_notification_settings\Entity\NotificationSettingEntity $entity */
    $row['id'] = $entity->id();
    $row['name'] = Link::createFromRoute(
      $entity->label(),
      'entity.notification_settings.edit_form',
      ['notification_settings' => $entity->id()]
    );
    return $row + parent::buildRow($entity);
  }

}

<?php

namespace Drupal\dm_notification_settings\Entity;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\RevisionLogInterface;
use Drupal\Core\Entity\EntityChangedInterface;
use Drupal\Core\Entity\EntityPublishedInterface;
use Drupal\user\EntityOwnerInterface;

/**
 * Provides an interface for defining User Notification Settings entities.
 *
 * @ingroup dm_notification_settings
 */
interface NotificationSettingEntityInterface extends ContentEntityInterface, RevisionLogInterface, EntityChangedInterface, EntityPublishedInterface, EntityOwnerInterface {

  /**
   * Add get/set methods for your configuration properties here.
   */
  const EMAIL_OFF = 'off';
  const EMAIL_INSTANT = 'email_instant';
  const EMAIL_DAILY = 'daily';
  const EMAIL_WEEKLY = 'weekly';
  const EMAIL_MONTHLY = 'monthly';

  const FIELD_BUNDLE_MAPPING = [
    'challenge' => 'field_challenge_status',
    'conversation' => 'field_conversation_status',
    'insight_navigator' => 'field_insight_navigator_status',
    'reviews' => 'field_reviews_status',
    'solution' => 'field_solution_status',
    'subscription_support' => 'field_subscription_support_status',
    'technology_update' => 'field_technology_update_status',
    'leads' => 'field_lead_status',
  ];

  /**
   * Default mail interval per notification type.
   */
  const DEFAULT_MAIL_INTERVAL = [
    'conversation' => self::EMAIL_DAILY,
    'challenge' => self::EMAIL_DAILY,
    'technology_update' => self::EMAIL_WEEKLY,
    'leads' => self::EMAIL_WEEKLY,
    'solution' => self::EMAIL_WEEKLY,
  ];

  /**
   * Gets the User Notification Settings name.
   *
   * @return string
   *   Name of the User Notification Settings.
   */
  public function getName();

  /**
   * Sets the User Notification Settings name.
   *
   * @param string $name
   *   The User Notification Settings name.
   *
   * @return \Drupal\dm_notification_settings\Entity\NotificationSettingEntityInterface
   *   The called User Notification Settings entity.
   */
  public function setName($name);

  /**
   * Gets the User Notification Settings creation timestamp.
   *
   * @return int
   *   Creation timestamp of the User Notification Settings.
   */
  public function getCreatedTime();

  /**
   * Sets the User Notification Settings creation timestamp.
   *
   * @param int $timestamp
   *   The User Notification Settings creation timestamp.
   *
   * @return \Drupal\dm_notification_settings\Entity\NotificationSettingEntityInterface
   *   The called User Notification Settings entity.
   */
  public function setCreatedTime($timestamp);

  /**
   * Gets the User Notification Settings revision creation timestamp.
   *
   * @return int
   *   The UNIX timestamp of when this revision was created.
   */
  public function getRevisionCreationTime();

  /**
   * Sets the User Notification Settings revision creation timestamp.
   *
   * @param int $timestamp
   *   The UNIX timestamp of when this revision was created.
   *
   * @return \Drupal\dm_notification_settings\Entity\NotificationSettingEntityInterface
   *   The called User Notification Settings entity.
   */
  public function setRevisionCreationTime($timestamp);

  /**
   * Gets the User Notification Settings revision author.
   *
   * @return \Drupal\user\UserInterface
   *   The user entity for the revision author.
   */
  public function getRevisionUser();

  /**
   * Sets the User Notification Settings revision author.
   *
   * @param int $uid
   *   The user ID of the revision author.
   *
   * @return \Drupal\dm_notification_settings\Entity\NotificationSettingEntityInterface
   *   The called User Notification Settings entity.
   */
  public function setRevisionUserId($uid);

}

<?php

namespace Drupal\dm_notification_settings;

use Drupal\Core\Entity\ContentEntityStorageInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Language\LanguageInterface;
use Drupal\dm_notification_settings\Entity\NotificationSettingEntityInterface;

/**
 * Defines the storage handler class for User Notification Settings entities.
 *
 * This extends the base storage class, adding required special handling for
 * User Notification Settings entities.
 *
 * @ingroup dm_notification_settings
 */
interface NotificationSettingEntityStorageInterface extends ContentEntityStorageInterface {

  /**
   * Gets a list of Settings revision IDs for a specific Settings.
   *
   * @param \Drupal\dm_notification_settings\Entity\NotificationSettingEntityInterface $entity
   *   The User Notification Settings entity.
   *
   * @return int[]
   *   User Notification Settings revision IDs (in ascending order).
   */
  public function revisionIds(NotificationSettingEntityInterface $entity);

  /**
   * Gets a list of revision IDs having a given user as Settings author.
   *
   * @param \Drupal\Core\Session\AccountInterface $account
   *   The user entity.
   *
   * @return int[]
   *   User Notification Settings revision IDs (in ascending order).
   */
  public function userRevisionIds(AccountInterface $account);

  /**
   * Counts the number of revisions in the default language.
   *
   * @param \Drupal\dm_notification_settings\Entity\NotificationSettingEntityInterface $entity
   *   The User Notification Settings entity.
   *
   * @return int
   *   The number of revisions in the default language.
   */
  public function countDefaultLanguageRevisions(NotificationSettingEntityInterface $entity);

  /**
   * Unsets the language for all Settings with the given language.
   *
   * @param \Drupal\Core\Language\LanguageInterface $language
   *   The language object.
   */
  public function clearRevisionsLanguage(LanguageInterface $language);

}

<?php

namespace Drupal\dm_notification_settings;

use Drupal\Core\Entity\EntityAccessControlHandler;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Access\AccessResult;

/**
 * Access controller for the User Notification Settings entity.
 *
 * @see \Drupal\dm_notification_settings\Entity\NotificationSettingEntity.
 */
class NotificationSettingEntityAccessControlHandler extends EntityAccessControlHandler {

  /**
   * {@inheritdoc}
   */
  protected function checkAccess(EntityInterface $entity, $operation, AccountInterface $account) {
    /** @var \Drupal\dm_notification_settings\Entity\NotificationSettingEntityInterface $entity */

    switch ($operation) {

      case 'view':

        if (!$entity->isPublished()) {
          return AccessResult::allowedIfHasPermission($account, 'view unpublished user notification settings entities');
        }

        return AccessResult::allowedIfHasPermission($account, 'view published user notification settings entities');

      case 'update':

        return AccessResult::allowedIfHasPermission($account, 'edit user notification settings entities');

      case 'delete':

        return AccessResult::allowedIfHasPermission($account, 'delete user notification settings entities');
    }

    // Unknown operation, no opinion.
    return AccessResult::neutral();
  }

  /**
   * {@inheritdoc}
   */
  protected function checkCreateAccess(AccountInterface $account, array $context, $entity_bundle = NULL) {
    return AccessResult::allowedIfHasPermission($account, 'add user notification settings entities');
  }

}

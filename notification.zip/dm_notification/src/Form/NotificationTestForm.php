<?php

namespace Drupal\dm_notification\Form;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\dm_notification\UserEmailNotificationSender;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Use this form to test notifications for specific user.
 */
class NotificationTestForm extends FormBase {

  /**
   * Entity type manager service.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   *   The user storage.
   */
  public $entityTypeManager;

  const EMAIL_NOTIFICATIONS = [
    'challenge' => 'Challenge',
    'conversation' => 'Conversation',
    'leads' => 'Leads',
    'solution' => 'Solution',
    'technology_update' => 'Technology Update',
  ];

  /**
   * Notification sender service.
   *
   * @var \Drupal\dm_notification\UserEmailNotificationSender
   *   The notification sender service.
   */
  public $notificationSenderService;

  /**
   * Construct notification test form.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager service.
   * @param \Drupal\dm_notification\UserEmailNotificationSender $notification_sender_service
   *   The notification sender service.
   */
  public function __construct(
    EntityTypeManagerInterface $entity_type_manager,
    UserEmailNotificationSender $notification_sender_service
  ) {
    $this->entityTypeManager = $entity_type_manager;
    $this->notificationSenderService = $notification_sender_service;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container): object {
    return new static(
      $container->get('entity_type.manager'),
      $container->get('dm_notification.user_email_sender')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId(): string {
    return 'dm_notification_test_from';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state): array {
    $form = [];
    $form['user'] = [
      '#type' => 'entity_id_autocomplete',
      '#target_type' => 'user',
      '#title' => $this->t('Select User'),
      '#description' => $this->t('Search a user by name or UID and and generate test notification for this user.'),
      '#required' => TRUE,
    ];

    $form['notification_type'] = [
      '#type' => 'select',
      '#title' => $this->t('Select Notificatin Type'),
      '#description' => $this->t('Select notification type for sending email.'),
      '#options' => self::EMAIL_NOTIFICATIONS,
      '#required' => TRUE,
    ];

    $form['target_email'] = [
      '#type' => 'email',
      '#title' => $this->t('Target Email'),
      '#description' => $this->t('Enter email to which notification emails will be sent.'),
      '#required' => TRUE,
    ];

    $form['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Send Notificaiton Email'),
    ];
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state): void {
    $values = $form_state->getValues();
    $uid = (int) $values['user'];
    $this->notificationSenderService->setTargetEmailId($values['target_email']);
    // Keep notification as unsent.
    $this->notificationSenderService->setNotificationEmailStatusValue(2);
    if (
      $values['notification_type'] === 'conversation'
    ) {
      $this->notificationSenderService->sendConversationNotification($uid);
    }

    if ($values['notification_type'] === 'technology_update') {
      $this->notificationSenderService->sendTechUpdateNotification($uid);
    }

    if ($values['notification_type'] === 'challenge') {
      $this->notificationSenderService->sendChallengeNotification($uid);
    }

    if ($values['notification_type'] === 'solution') {
      $this->notificationSenderService->sendSolutionNotification($uid);
    }

    if ($values['notification_type'] === 'leads') {
      $this->notificationSenderService->sendLeadsNotification($uid);
    }
    if ($this->notificationSenderService->emailSent === TRUE) {
      $this->messenger()->addMessage($this->t('Please check the mailbox for @email to verify the generated email.', ['@email' => $values['target_email']]));
    }
    else {
      $user = $this->entityTypeManager->getStorage('user')->load($uid);
      $this->messenger()->addMessage($this->t('Something went wrong, Please check if you have any unsent notifications to send for user @email.', ['@email' => $user->getEmail()]));
    }
  }

}

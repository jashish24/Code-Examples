<?php

namespace Drupal\dm_notification\Form;

use Drupal\Core\Entity\EntityForm;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Entity\EntityTypeBundleInfoInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;

/**
 * User settings for notification form.
 */
class UserNotificationSettingsForm extends EntityForm {

  /**
   * Entity type bundle information.
   *
   * @var \Drupal\Core\Entity\EntityTypeBundleInfoInterface
   */
  protected $entityTypeBundleInfo;

  /**
   * Entity manager service.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The object constructor.
   */
  public function __construct(EntityTypeBundleInfoInterface $entity_info_bundle_info, EntityTypeManagerInterface $entity_type_manager) {
    $this->entityTypeBundleInfo = $entity_info_bundle_info;
    $this->entityTypeManager = $entity_type_manager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    // Instantiates this form class.
    return new static(
      // Load the service required to construct this class.
      $container->get('entity_type.bundle.info'),
      $container->get('entity_type.manager')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function form(array $form, FormStateInterface $form_state) {
    $form = parent::form($form, $form_state);

    /** @var \Drupal\dm_notification\Entity\UserNotificationSettings $user_notification_settings **/
    $user_notification_settings = $this->entity;
    $notification_types = $this->entityTypeBundleInfo->getBundleInfo('notification');
    $notification_type_options = [];
    $setting_user = NULL;

    $user_id = $user_notification_settings->get('user_id');
    if ($user_id !== NULL && is_numeric($user_id)) {
      $setting_user = $this->entityTypeManager->getStorage('user')->load($user_id);
    }

    $notification_type_storage = $this->entityTypeManager->getStorage('notification_type');

    foreach ($notification_types as $type => $notification_type) {
      /** @var \Drupal\dm_notification\Entity\NotificationType **/
      $notification_type_obj = $notification_type_storage->load($type);
      $summary = $notification_type_obj->getSummary();
      $notification_type_options[$type] = $notification_type['label'] . "<span>{$summary}</span>";
    }

    $form['label'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Label'),
      '#maxlength' => 255,
      '#default_value' => $setting_user ? "User {$setting_user->id()}" : $user_notification_settings->label(),
      '#description' => $this->t("Label for the User Notification Settings."),
      '#required' => TRUE,
    ];

    $form['id'] = [
      '#type' => 'machine_name',
      '#default_value' => $user_notification_settings->id(),
      '#machine_name' => [
        'exists' => '\Drupal\dm_notification\Entity\UserNotificationSettings::load',
      ],
      '#disabled' => !$user_notification_settings->isNew(),
    ];

    $form['user_id'] = [
      '#type' => 'entity_autocomplete',
      '#title' => $this->t('Setting User'),
      '#description' => $this->t('User to which this setting is attached.'),
      '#selection_settings' => ['target_roles' => ['authenticated']],
      '#target_type' => 'user',
      '#default_value' => $setting_user,
      '#tags' => TRUE,
    ];

    $form['email_type_notification_wrapper'] = [
      '#type' => 'details',
      '#title' => $this->t('Email notification settings'),
      '#open' => TRUE,
      '#attributes' => [
        'class' => [
          'email-notification-settings-wrapper',
        ],
      ],
    ];

    // @todo Fix required settings here.
    unset($notification_type_options['insight_navigator']);
    unset($notification_type_options['reviews']);
    unset($notification_type_options['subscription_support']);
    unset($notification_type_options['solution']);

    // Set frequency for each notification type email.
    foreach ($notification_type_options as $notification_type => $notification_type_option) {
      $form['email_type_notification_wrapper']["{$notification_type}_email_status"] = [
        '#type' => 'radios',
        '#title' => $notification_type_option,
        '#description' => $this->t('Set frequency to receive notification'),
        '#options' => $user_notification_settings->getFrequencyOptions(),
        '#default_value' => $user_notification_settings->get("{$notification_type}_email_status"),
        '#attributes' => [
          'class' => [
            'email-radios-wrapper',
          ],
        ],
      ];
    }

    $form['type_notification_status'] = [
      '#type' => 'checkboxes',
      '#default_value' => $user_notification_settings->get('type_notification_status'),
      '#options' => $notification_type_options,
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function save(array $form, FormStateInterface $form_state) {
    /** @var \Drupal\dm_notification_settings\Entity\NotificationSettingEntity $user_notification_settings **/
    $user_notification_settings = $this->entity;
    $user_id = $form_state->getValue('user_id');
    $user_id = reset($user_id);
    $user_notification_settings->set('user_id', $user_id['target_id']);

    // Save email type notification settings.
    $notification_types = $this->entityTypeBundleInfo->getBundleInfo('notification');

    foreach (array_keys($notification_types) as $type) {
      $key = "{$type}_email_status";
      $value = $form_state->getValue($key);
      $user_notification_settings->set($key, $value);
    }

    // Save settings.
    $status = $user_notification_settings->save();

    switch ($status) {
      case SAVED_NEW:
        $this->messenger()->addMessage($this->t('Created the %label User Notification Settings.', [
          '%label' => $user_notification_settings->label(),
        ]));
        break;

      default:
        $this->messenger()->addMessage($this->t('Saved the %label User Notification Settings.', [
          '%label' => $user_notification_settings->label(),
        ]));
    }

    return $user_notification_settings->id();
  }

}

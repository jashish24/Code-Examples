<?php

namespace Drupal\dm_notification\Form;

use Drupal\Core\Entity\EntityForm;
use Drupal\Core\Form\FormStateInterface;

/**
 * Notification bundle form.
 */
class NotificationTypeForm extends EntityForm {

  /**
   * {@inheritdoc}
   */
  public function form(array $form, FormStateInterface $form_state) {
    $form = parent::form($form, $form_state);

    /** @var \Drupal\dm_notification\Entity\NotificationType **/
    $notification_type = $this->entity;
    $form['label'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Label'),
      '#maxlength' => 255,
      '#default_value' => $notification_type->label(),
      '#description' => $this->t("Label for the Notification type."),
      '#required' => TRUE,
    ];

    $form['id'] = [
      '#type' => 'machine_name',
      '#default_value' => $notification_type->id(),
      '#machine_name' => [
        'exists' => '\Drupal\dm_notification\Entity\NotificationType::load',
      ],
      '#disabled' => !$notification_type->isNew(),
    ];

    $form['summary'] = [
      '#type' => 'textarea',
      '#default_value' => $notification_type->getSummary(),
      '#description' => $this->t('Summary about this notification type.'),
    ];

    /* You will need additional form elements for your custom properties. */

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function save(array $form, FormStateInterface $form_state) {
    /** @var \Drupal\dm_notification\Entity\NotificationType **/
    $notification_type = $this->entity;
    $notification_type->setSummary($form_state->getValue('summary'));
    $status = $notification_type->save();

    switch ($status) {
      case SAVED_NEW:
        $this->messenger()->addMessage($this->t('Created the %label Notification type.', [
          '%label' => $notification_type->label(),
        ]));
        break;

      default:
        $this->messenger()->addMessage($this->t('Saved the %label Notification type.', [
          '%label' => $notification_type->label(),
        ]));
    }
    $form_state->setRedirectUrl($notification_type->toUrl('collection'));

    return $notification_type->id();
  }

}

<?php

namespace Drupal\dm_notification;

use Drupal\Core\Entity\ContentEntityStorageInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Language\LanguageInterface;
use Drupal\dm_notification\Entity\NotificationInterface;

/**
 * Defines the storage handler class for Notification entities.
 *
 * This extends the base storage class, adding required special handling for
 * Notification entities.
 *
 * @ingroup dm_notification
 */
interface NotificationStorageInterface extends ContentEntityStorageInterface {

  /**
   * Gets a list of Notification revision IDs for a specific Notification.
   *
   * @param \Drupal\dm_notification\Entity\NotificationInterface $entity
   *   The Notification entity.
   *
   * @return int[]
   *   Notification revision IDs (in ascending order).
   */
  public function revisionIds(NotificationInterface $entity);

  /**
   * Gets a list of revision IDs having a given user as Notification author.
   *
   * @param \Drupal\Core\Session\AccountInterface $account
   *   The user entity.
   *
   * @return int[]
   *   Notification revision IDs (in ascending order).
   */
  public function userRevisionIds(AccountInterface $account);

  /**
   * Counts the number of revisions in the default language.
   *
   * @param \Drupal\dm_notification\Entity\NotificationInterface $entity
   *   The Notification entity.
   *
   * @return int
   *   The number of revisions in the default language.
   */
  public function countDefaultLanguageRevisions(NotificationInterface $entity);

  /**
   * Unsets the language for all Notification with the given language.
   *
   * @param \Drupal\Core\Language\LanguageInterface $language
   *   The language object.
   */
  public function clearRevisionsLanguage(LanguageInterface $language);

}

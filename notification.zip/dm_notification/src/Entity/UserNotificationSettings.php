<?php

namespace Drupal\dm_notification\Entity;

use Drupal\Core\Config\Entity\ConfigEntityBase;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Defines the User Notification Settings entity.
 *
 * @ConfigEntityType(
 *   id = "user_notification_settings",
 *   label = @Translation("User Notification Settings"),
 *   handlers = {
 *     "view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 *     "list_builder" = "Drupal\dm_notification\UserNotificationSettingsListBuilder",
 *     "form" = {
 *       "add" = "Drupal\dm_notification\Form\UserNotificationSettingsForm",
 *       "edit" = "Drupal\dm_notification\Form\UserNotificationSettingsForm",
 *       "delete" = "Drupal\dm_notification\Form\UserNotificationSettingsDeleteForm"
 *     },
 *     "route_provider" = {
 *       "html" = "Drupal\dm_notification\UserNotificationSettingsHtmlRouteProvider",
 *     },
 *   },
 *   config_prefix = "user_notification_settings",
 *   admin_permission = "administer site configuration",
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "label",
 *     "uuid" = "uuid"
 *   },
 *   config_export = {
 *     "id",
 *     "label",
 *     "user_id",
 *     "enable_email_all",
 *     "email_type_notification_status",
 *     "email_notification_frequency",
 *     "conversation_email_status",
 *     "challenge_email_status",
 *     "insight_navigator_email_status",
 *     "reviews_email_status",
 *     "subscription_support_email_status",
 *     "technology_update_email_status",
 *     "type_notification_status"
 *   },
 *   links = {
 *     "canonical" = "/admin/structure/user_notification_settings/{user_notification_settings}",
 *     "add-form" = "/admin/structure/user_notification_settings/add",
 *     "edit-form" = "/admin/structure/user_notification_settings/{user_notification_settings}/edit",
 *     "delete-form" = "/admin/structure/user_notification_settings/{user_notification_settings}/delete",
 *     "collection" = "/admin/structure/user_notification_settings"
 *   }
 * )
 */
class UserNotificationSettings extends ConfigEntityBase implements UserNotificationSettingsInterface {
  use StringTranslationTrait;

  const EMAIL_OFF = 'off';
  const EMAIL_INSTANT = 'email_instant';
  const EMAIL_DAILY = 'daily';
  const EMAIL_WEEKLY = 'weekly';
  const EMAIL_MONTHLY = 'monthly';

  /**
   * The User Notification Settings ID.
   *
   * @var string
   */
  protected $id;

  /**
   * The User Notification Settings label.
   *
   * @var string
   */
  protected $label;

  /**
   * The user attached to this setting.
   *
   * @var int
   */
  protected $user_id;

  /**
   * If all user email notifications are enabled.
   *
   * @var bool
   */
  protected $enable_email_all = TRUE;

  /**
   * Email notification frequency.
   *
   * Daily, Weekly or Monthly.
   *
   * @var string
   */
  protected $email_notification_frequency = self::EMAIL_DAILY;

  /**
   * Set default challenge email setting.
   *
   * Daily, Weekly or Monthly.
   *
   * @var string
   */
  protected $challenge_email_status = self::EMAIL_DAILY;

  /**
   * Site notification type enable status.
   *
   * @var array
   */
  protected $type_notification_status = [
    'insight_navigator' => 'insight_navigator',
    'conversation' => 'conversation',
    'reviews' => 'reviews',
    'subscription_support' => 'subscription_support',
    'technology_update' => 'technology_update',
    'challenge' => 'challenge',
  ];

  /**
   * {@inheritdoc}
   */
  public function getFrequencyOptions() {
    return [
      self::EMAIL_OFF => $this->t('Off'),
      self::EMAIL_DAILY => $this->t('Daily'),
      self::EMAIL_WEEKLY => $this->t('Weekly'),
      self::EMAIL_MONTHLY => $this->t('Monthly'),
    ];
  }

}

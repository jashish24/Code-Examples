<?php

namespace Drupal\dm_notification\Entity;

use Drupal\Core\Config\Entity\ConfigEntityInterface;

/**
 * Provides an interface for defining Notification type entities.
 */
interface NotificationTypeInterface extends ConfigEntityInterface {

  // Add get/set methods for your configuration properties here.
}

<?php

namespace Drupal\dm_notification\Entity;

use Drupal\Core\Config\Entity\ConfigEntityInterface;

/**
 * Provides an interface for defining User Notification Settings entities.
 */
interface UserNotificationSettingsInterface extends ConfigEntityInterface {

  // Add get/set methods for your configuration properties here.
}

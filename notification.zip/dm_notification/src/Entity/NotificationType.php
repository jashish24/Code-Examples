<?php

namespace Drupal\dm_notification\Entity;

use Drupal\Core\Config\Entity\ConfigEntityBundleBase;

/**
 * Defines the Notification type entity.
 *
 * @ConfigEntityType(
 *   id = "notification_type",
 *   label = @Translation("Notification type"),
 *   handlers = {
 *     "view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 *     "list_builder" = "Drupal\dm_notification\NotificationTypeListBuilder",
 *     "form" = {
 *       "add" = "Drupal\dm_notification\Form\NotificationTypeForm",
 *       "edit" = "Drupal\dm_notification\Form\NotificationTypeForm",
 *       "delete" = "Drupal\dm_notification\Form\NotificationTypeDeleteForm"
 *     },
 *     "route_provider" = {
 *       "html" = "Drupal\dm_notification\NotificationTypeHtmlRouteProvider",
 *     },
 *   },
 *   config_prefix = "notification_type",
 *   admin_permission = "administer site configuration",
 *   bundle_of = "notification",
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "label",
 *     "uuid" = "uuid"
 *   },
 *   config_export = {
 *     "id" = "id",
 *     "label" = "label",
 *     "summary" = "summary",
 *   },
 *   links = {
 *     "canonical" = "/admin/structure/notification_type/{notification_type}",
 *     "add-form" = "/admin/structure/notification_type/add",
 *     "edit-form" = "/admin/structure/notification_type/{notification_type}/edit",
 *     "delete-form" = "/admin/structure/notification_type/{notification_type}/delete",
 *     "collection" = "/admin/structure/notification_type"
 *   }
 * )
 */
class NotificationType extends ConfigEntityBundleBase implements NotificationTypeInterface {

  /**
   * The Notification type ID.
   *
   * @var string
   */
  protected $id;

  /**
   * The Notification type label.
   *
   * @var string
   */
  protected $label;

  /**
   * The Notification type summary.
   *
   * @var string
   */
  protected $summary;

  /**
   * {@inheritdoc}
   */
  public function getSummary() {
    return $this->summary;
  }

  /**
   * {@inheritdoc}
   */
  public function setSummary($summary) {
    $this->set('summary', $summary);
    return $this;
  }

}

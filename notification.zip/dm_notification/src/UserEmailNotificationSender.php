<?php

namespace Drupal\dm_notification;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\File\FileUrlGeneratorInterface;
use Drupal\Core\Url;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\dm_user\DmUserGeneralService;
use Drupal\Core\Language\LanguageManagerInterface;
use Drupal\Core\Mail\MailManagerInterface;
use Drupal\Core\Render\RendererInterface;
use Drupal\dm_challenge\Entity\SolutionEntity;
use Drupal\dm_company\Entity\Company;
use Drupal\dm_csv\Utility\NodeViewCountService;
use Drupal\file\FileInterface;
use Drupal\node\NodeInterface;
use Drupal\subscription_package\Utility\UserPackageDetails;
use Drupal\user\Entity\User;
use Drupal\user\UserInterface;
use Drupal\dm_domain\DmDomainHelper;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\dm_tagging\Utility\TaggingService;
use Drupal\node\Entity\Node;

/**
 * User email notification sender class.
 */
class UserEmailNotificationSender {
  use StringTranslationTrait;

  /**
   * Drupal\Core\Entity\EntityTypeManagerInterface definition.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * Notification storage.
   *
   * @var \Drupal\dm_notification\NotificationStorage
   */
  protected $notificationStorage;

  /**
   * User storage.
   *
   * @var \Drupal\user\UserStorage
   */
  protected $userStorage;

  /**
   * General service.
   *
   * @var \Drupal\dm_user\DmUserGeneralService
   */
  protected $dmGeneralService;

  /**
   * Language manager service.
   *
   * @var \Drupal\Core\Language\LanguageManagerInterface
   */
  protected $languageManager;

  /**
   * Drupal mail manager.
   *
   * @var \Drupal\Core\Mail\MailManagerInterface
   */
  protected $mailManager;

  /**
   * File uri to url generator.
   *
   * @var \Drupal\Core\File\FileUrlGenerator
   */
  protected $fileUrlGenerator;

  /**
   * Drupal\subscription_package\Utility\UserPackageDetails definition.
   *
   * @var \Drupal\subscription_package\Utility\UserPackageDetails
   */
  protected $subscriptionPackage;

  /**
   * The renderer service.
   *
   * @var \Drupal\Core\Render
   */
  protected $renderer;

  /**
   * Domain helper service.
   *
   * @var \Drupal\dm_domain\DmDomainHelper
   */
  protected $domainHelper;

  /**
   * Domain helper service.
   *
   * @var Drupal\dm_csv\Utility\NodeViewCountService
   */
  protected $nodeViewCountService;

  /**
   * The form builder.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * The dm_tagging.default service.
   *
   * @var \Drupal\dm_tagging\Utility\TaggingService
   */
  protected $tagging;

  /**
   * Send notification to this email if present.
   *
   * @var string
   */
  private $targetEmailId = NULL;

  /**
   * Notification email status value.
   *
   * @var int
   */
  private $notificationEmailStatus = 1;

  /**
   * Flag for email sent for user.
   *
   * @var bool
   */
  public $emailSent = FALSE;

  /**
   * Constructs a new UserEmailNotificationSender object.
   */
  public function __construct(
    EntityTypeManagerInterface $entity_type_manager,
    DmUserGeneralService $dm_general_srvice,
    LanguageManagerInterface $language_manager,
    MailManagerInterface $mail_manager,
    FileUrlGeneratorInterface $file_url_generator,
    UserPackageDetails $subscription_package,
    RendererInterface $renderer,
    DmDomainHelper $domain_helper_service,
    NodeViewCountService $node_view_count_service,
    ConfigFactoryInterface $config_factory,
    TaggingService $tagging
  ) {
    $this->entityTypeManager = $entity_type_manager;
    $this->notificationStorage = $entity_type_manager->getStorage('notification');
    $this->userStorage = $entity_type_manager->getStorage('user');
    $this->dmGeneralService = $dm_general_srvice;
    $this->languageManager = $language_manager;
    $this->mailManager = $mail_manager;
    $this->fileUrlGenerator = $file_url_generator;
    $this->subscriptionPackage = $subscription_package;
    $this->renderer = $renderer;
    $this->domainHelper = $domain_helper_service;
    $this->nodeViewCountService = $node_view_count_service;
    $this->configFactory = $config_factory;
    $this->tagging = $tagging;
  }

  /**
   * Set target email id.
   *
   * @param string $email_id
   *   Target email id used for finallly sending the email.
   */
  public function setTargetEmailId($email_id) {
    $this->targetEmailId = $email_id;
  }

  /**
   * Set notification email status value.
   *
   * @param int $email_status
   *   Notification email status value.
   */
  public function setNotificationEmailStatusValue($email_status) {
    $this->notificationEmailStatus = $email_status;
  }

  /**
   * Get target email id.
   *
   * @return string
   *   Target email id.
   */
  public function getTargetEmailId() {
    return $this->targetEmailId;
  }

  /**
   * Get notification email status to set.
   *
   * @return int
   *   Get notification email status to set.
   */
  public function getNotificationEmailStatusValue() {
    return $this->notificationEmailStatus;
  }

  /**
   * Sends conversation email notifications.
   *
   * @param int $uid
   *   User ID.
   */
  public function sendConversationNotification($uid = 0) {
    $conversation_notifications = $this->notificationStorage->loadByProperties([
      'field_user' => $uid,
      'field_email_status' => 2,
      'type' => 'conversation',
    ]);

    // Continue, if no notification found.
    if (count($conversation_notifications) === 0) {
      return;
    }

    $user_notifications = [];

    foreach ($conversation_notifications as $pending_notification) {
      $link = FALSE;
      /** @var \Drupal\dm_notification\Entity\Notification $pending_notification **/

      // Update with link field first.
      if ($pending_notification->hasField('field_link') && !$pending_notification->get('field_link')->isEmpty()) {
        $link = $pending_notification->get('field_link')->value;
      }

      // Thread field takes priority.
      $thread_found = $pending_notification->hasField('field_message_thread') && !$pending_notification->get('field_message_thread')->isEmpty();

      if ($thread_found !== FALSE) {
        $link = $pending_notification->get('field_message_thread')->target_id;
      }

      // Update only when related thread or thread link is found.
      if ($link !== FALSE) {
        if (!isset($user_notifications[$link])) {
          $user_notifications[$link] = [
            'count' => 0,
          ];
        }
        $user_notifications[$link]['count']++;

        /** @var \Drupal\user\Entity\User $notification_owner **/
        $notification_owner = $pending_notification->getOwner();
        $user_notifications[$link]['company_name'] = $this->t('No company assigned');

        // Update with owner company.
        if (
          $notification_owner instanceof UserInterface &&
          $notification_owner->hasField('field_company') &&
          $notification_owner->get('field_company')->entity instanceof Company
        ) {
          /** @var \Drupal\dm_company\Entity\Company $user_company **/
          $user_company = $notification_owner->get('field_company')->entity;
          $user_notifications[$link]['company_name'] = $user_company->getName();
        }

        // Add technology name.
        if ($thread_found !== FALSE) {
          /** @var \Drupal\private_message\Entity\PrivateMessageThread $message_thread **/
          $message_thread = $pending_notification->get('field_message_thread')->entity;

          if ($message_thread->hasField('field_related_technology') && !$message_thread->get('field_related_technology')->isEmpty()) {
            $user_notifications[$link]['tech_name'] = $message_thread->get('field_related_technology')->entity->label();
          }
        }
      }
    }

    // Send Emails.
    if (count($user_notifications) > 0) {
      $user_obj = $this->userStorage->load($uid);
      $user_mail = $user_obj->getEmail();
      $params = [
        'subject' => $this->t('You have new messages on :date', [
          ':date' => date("F j, Y"),
        ]),
      ];

      // Start body content.
      $body = $this->startBodyContent($user_obj);

      // Sub-Heading.
      $body[] = $this->t('<div class="heading"><h3>Recently received messages</h3></div>');

      foreach ($user_notifications as $notification) {
        $body[] = $this->t('<div class="notification-row"><p>:count Notifications from ":company_name" for ":tech_name"</p></div>', [
          ':count' => $notification['count'],
          ':company_name' => $notification['company_name'],
          ':tech_name' => $notification['tech_name'] ?? $this->t('No tech'),
        ]);
      }

      // Notification user.
      $user_host = $this->domainHelper->getUserDomainPath($user_obj);
      $params['host'] = $user_host;

      // Add end body contents.
      $this->endBodyContent($body);
      $params['footer'] = $this->getMailFooter($user_obj, $user_host);
      // Pass mail content.
      $params['body'] = $body;

      // Send mail.
      $this->triggerEmails($params, $user_mail, $conversation_notifications);
    }
  }

  /**
   * Sends tech update email notifications.
   *
   * @param int $uid
   *   User ID.
   */
  public function sendTechUpdateNotification($uid = 0) {
    $tech_update_notifications_all = $this->notificationStorage->loadByProperties([
      'field_user' => $uid,
      'field_email_status' => 2,
      'type' => 'technology_update',
    ]);

    // Continue, if no notification found.
    if (count($tech_update_notifications_all) === 0) {
      return;
    }

    // Send only eight cards.
    $tech_update_notifications = array_slice($tech_update_notifications_all, 0, 8, TRUE);

    $user_notifications = [];

    foreach ($tech_update_notifications as $pending_notification) {
      $link = 0;
      $related_technology = NULL;
      /** @var \Drupal\dm_notification\Entity\Notification $pending_notification **/
      if ($pending_notification->hasField('field_related_technology') && $pending_notification->get('field_related_technology')->entity instanceof NodeInterface) {
        $related_technology = $pending_notification->get('field_related_technology')->entity;
        $link = $related_technology->id();
      }

      $user_notifications[$link]['technology'] = $related_technology;
    }

    // Send Emails.
    if (count($user_notifications) > 0) {
      $pending_notification = reset($tech_update_notifications);
      $user_obj = $this->userStorage->load($uid);
      $user_mail = $user_obj->getEmail();
      $params = [
        'subject' => $this->t('Your technology updates for :date', [
          ':date' => date("F j, Y"),
        ]),
      ];

      // Notification user domain.
      $user_host = $this->domainHelper->getUserDomainPath($user_obj);
      $user_active_domains = $this->domainHelper->getUserActiveDomains($user_obj);

      // Update with notification domain.
      if ($pending_notification->hasField('field_domain') && !$pending_notification->get('field_domain')->isEmpty() && $pending_notification->get('field_domain')->entity) {
        $notification_domain = $pending_notification->get('field_domain')->entity;
        $notification_domain_id = $notification_domain->id();

        if (in_array($notification_domain_id, $user_active_domains, TRUE)) {
          $user_host = $notification_domain->getRawPath();
        }
      }

      // Define mail key for alterations.
      $mail_key = 'tech_update_notification';

      // Start body content.
      $body = $this->startBodyContent($user_obj, $user_host, $mail_key);

      // User domain host.
      $params['host'] = $user_host;

      // Notification grouping.
      $grouped_notifications = [];
      $i = 0;
      $j = 1;
      foreach ($user_notifications as $notification) {
        if ($j > 2) {
          $j = 1;
        }

        $grouped_notifications[$i][$j]['technology'] = $notification['technology'];

        if ($j % 2 == 0) {
          $i++;
        }
        $j++;
      }
      // Build cards in group of two.
      foreach ($grouped_notifications as $notifications) {
        $data = [];
        $tech1 = $notifications[1]['technology'];
        // Host as per user domain settings.
        $data['user_host'] = $user_host;
        if ($tech1 instanceof Node) {
          $data['cards']['card_1'] = $this->prepareTechCard($tech1);
        }
        if (isset($notifications[2])) {
          $tech2 = $notifications[2]['technology'];
          if ($tech2 instanceof Node) {
            $data['cards']['card_2'] = $this->prepareTechCard($tech2);
          }
        }
        // Theme cards.
        $build = [
          '#theme' => 'tech_update_mail_cards',
          '#data' => $data,
        ];
        $card_build = $this->renderer->renderInIsolation($build);

        $body[] = $card_build;
      }

      // View all link.
      $body[] = $this->t('<p><a href=":user_host/user/technologies-in-your-area-of-interests" title="View all">View all</a> technologies in my area of interests.</p>', [
        ':user_host' => $user_host,
      ]);

      // Add edit interests link here.
      $body[] = $this->t('<p>In case the above technologies don\'t match your interests, update your area of interests <a href=":user_host/user/login?destination=user/:uid/toolbox/edit-user-interests">here</a>.</p>', [
        ':user_host' => $user_host,
        ':uid' => $uid,
      ]);

      // Add end body contents.
      $this->endBodyContent($body);
      $params['footer'] = $this->getMailFooter($user_obj, $user_host);
      // Pass mail content.
      $params['body'] = $body;

      // Send mail.
      $this->triggerEmails($params, $user_mail, $tech_update_notifications_all, $mail_key);
    }
  }

  /**
   * Prepare tech card.
   *
   * @param \Drupal\node\Entity\Node $tech
   *   The technology node.
   *
   * @return array
   *   Renderable tech card array.
   */
  protected function prepareTechCard(Node $tech) {
    $view_builder = $this->entityTypeManager->getViewBuilder('node');
    $card = [];
    $card['field_thumbnail'] = $view_builder->viewField($tech->get('field_thumbnail'), 'mail_card');
    $card['title'] = $tech->getTitle();
    $card['field_subtitle'] = $view_builder->viewField($tech->get('field_subtitle'), 'mail_card');
    $tech_tags = $this->tagging->getTagsForEntity($tech);
    if (count($tech_tags) > 0) {
      $tech_tags = array_slice($tech_tags, 0, 3);
      $card['technology_keywords'] = [
        '#type' => 'inline_template',
        '#prefix' => '<div class="tech-chips-wrapper">',
        '#template' => '<div class="show-chips card-chips"><span class="card-chips-items">{{ keywords|raw }}</span></div>',
        '#suffix' => '</div>',
        '#context' => [
          'keywords' => implode('</span><span class="card-chips-items">', $tech_tags),
        ],
      ];
    }
    $card['tech_url'] = $tech->toUrl()->toString();
    return $card;
  }

  /**
   * Get company logo Url.
   *
   * @param \Drupal\dm_company\Entity\Company $company
   *   The company entity.
   *
   * @return string
   *   company relative URL.
   */
  protected function getCompanyLogoUrl(Company $company) {
    $logo_url = '/themes/atom/deploymentmatters/images/logos/no_company_emailer_logo.png';
    if (
      $company->hasField('field_logo') &&
      $company->get('field_logo')->entity instanceof FileInterface
    ) {
      $file_entity = $company->get('field_logo')->entity;
      $company_logo = $file_entity->getFileUri();
      $logo_url = $this->fileUrlGenerator->generateString($company_logo);
    }
    return $logo_url;
  }

  /**
   * Build body with message cards.
   *
   * @param array $formatted_notifications
   *   Array of notification to process to generate email body.
   * @param \Drupal\user\UserInterface $receiver
   *   User entity.
   * @param string $receiver_host
   *   Host URL to user for links and images.
   * @param bool $pro_access
   *   True if user is having access to pro leads.
   *
   * @return string
   *   Rendered company logo details to add in email body.
   */
  protected function buildBodyWithMessageCards($formatted_notifications, UserInterface $receiver, string $receiver_host, bool $pro_access) {
    $tech_name_with_cards_build_body = '';
    $tech_name_with_cards = [];
    // Sub-Heading.
    foreach ($formatted_notifications as $tech_id => $leads) {
      $tech_node = $this->entityTypeManager->getStorage('node')->load($tech_id);
      $tech_name_with_cards[$tech_id]['tech_name'] = $tech_node->getTitle();
      $message_cards = [];
      foreach ($leads as $userId => $lead_types) {
        $message_card = [];
        $sender = $this->entityTypeManager->getStorage('user')->load($userId);
        $full_name = $this->dmGeneralService->resolveUsername($sender, TRUE);
        // Prepare notification card data.
        // Get job details.
        $job_details = $this->t('working');
        if (
          $sender->hasField('field_job_title') &&
          !$sender->get('field_job_title')->isEmpty()
        ) {
          $job_details = $sender->get('field_job_title')->value;
        }
        // Get company of the user.
        $company_name = '';
        $company_logo_url = '';
        if (
          $sender->hasField('field_company') &&
          !$sender->get('field_company')->isEmpty() &&
          $sender->get('field_company')->entity instanceof Company
        ) {
          $company = $sender->get('field_company')->entity;
          $company_name = $company->getName();
          // $companyImage
          $logo_relative_url = $this->getCompanyLogoUrl($company);
          $company_logo_url = $receiver_host . $logo_relative_url;
        }
        $message_card['company_logo_url'] = $company_logo_url;
        // Get from date prefix.
        $thread_type = 'viewer';
        $message_card['is_pro'] = FALSE;
        $message_card['message_button_class'] = '';
        foreach ($lead_types as $leadType => $notifications) {
          // Get the last notification because that will be the latest one.
          $notification = array_pop($notifications);
          if ($leadType == 'view') {
            $message_card['view_from_date_prefix'] = $this->t('Viewed');
            // Get the latest view time for User.
            $nvc = $this->nodeViewCountService->getLatestRow($userId, $tech_id);
            if (isset($nvc['datetime'])) {
              $message_card['view_from_date'] = $nvc['datetime'];
            }
            $thread_type = 'viewer';
            if (
              $notification->hasField('field_lead_category') &&
              $notification->get('field_lead_category')->value == 'pro'
            ) {
              $message_card['is_pro'] = TRUE;
              $message_card['pro_tooltip'] = $this->t('Pro leads are only accessible in combination with our Pro subscription and allow you to message specific users already after their 1st visit to your page.');
            }
          }
          else {
            $message_card['follow_from_date_prefix'] = $this->t('Followed since');
            $message_card['follow_from_date'] = $notification->getCreatedTime();
            $thread_type = 'follower';
            $message_card['is_pro'] = FALSE;
          }
        }
        // Set thread link.
        $thread_url = Url::fromRoute(
          'dm_interaction_centre.create_thread_with_message',
          [
            'tech_node' => $tech_node->id(),
            'thread_type' => $thread_type,
            'user' => $receiver->id(),
            'receiver' => $sender->id(),
          ]
        )->toString();
        $message_button_url = Url::fromRoute(
          'user.login',
          [
            'destination' => $thread_url,
          ]
        )->toString();

        $message_card['full_name'] = $full_name;
        $message_card['job_details'] = $job_details;
        $message_card['company_name'] = $company_name;
        $message_card['message_button_link'] = $receiver_host . $message_button_url;

        // Disable button if pro access is not present for user.
        if (
          $message_card['is_pro'] == TRUE &&
          $pro_access == FALSE
        ) {
          // Remove thread url.
          $message_card['message_button_link'] = NULL;
          $message_card['message_button_class'] = 'disable';
        }

        $message_cards[$userId] = $message_card;
      }
      $tech_name_with_cards[$tech_id]['message_cards'] = $message_cards;
    }
    $upgrade_alias = Url::fromRoute(
      'user.login',
      [
        'destination' => '/pricing-suppliers/tc',
      ]
    )->toString();

    $tech_name_with_cards_build = [
      '#theme' => 'notification_supplier_leads_message_card',
      '#tech_name_with_cards' => $tech_name_with_cards,
      '#pro_access' => $pro_access,
      '#upgrade_link' => $receiver_host . $upgrade_alias,
    ];
    $tech_name_with_cards_build_body = $this->renderer->renderInIsolation($tech_name_with_cards_build);
    return $tech_name_with_cards_build_body;
  }

  /**
   * Build body with company logos.
   *
   * @param array $formatted_notifications
   *   Array of notification to process to generate email body.
   * @param \Drupal\user\UserInterface $receiver
   *   User entity.
   * @param string $receiver_host
   *   Host URL to user for links and images.
   *
   * @return string
   *   Rendered company logo details to add in email body.
   */
  protected function buildBodyWithCompanyLogos(array $formatted_notifications, UserInterface $receiver, string $receiver_host) {
    $companies = [];
    // Prepare unique array of companies.
    // There could be chance that users are from same company are leads.
    // Using below loop enlimate the duplicates.
    foreach ($formatted_notifications as $tech_notifications) {
      $userIds = array_keys($tech_notifications);
      foreach ($userIds as $userId) {
        $user = $this->entityTypeManager->getStorage('user')->load($userId);
        if (
          $user->hasField('field_company') &&
          $user->get('field_company')->entity instanceof Company
        ) {
          $company = $user->get('field_company')->entity;
          $relative_logo_url = $this->getCompanyLogoUrl($company);
          $companies[$company->id()]['logo_url'] = $receiver_host . $relative_logo_url;
          $companies[$company->id()]['company_name'] = $company->getName();
          $toolbox_technologies = Url::fromRoute('dm_toolbox.toolbox.redirect', [
            'user' => $receiver->id(),
            'fragment' => 'technologies',
          ])->toString();
          $action_url = Url::fromRoute(
            'user.login',
            [
              'destination' => $toolbox_technologies,
            ]
          )->toString();
          $companies[$company->id()]['action_link'] = $receiver_host . $action_url;
        }
      }
    }
    $view_leads_link = Url::fromRoute('dm_toolbox.toolbox.redirect', [
      'user' => $receiver->id(),
      'fragment' => 'technologies',
    ])->toString();
    $company_logos = [
      '#theme' => 'notification_supplier_leads_company_logo',
      '#companies' => $companies,
      '#view_leads_link' => $receiver_host . $view_leads_link,
    ];
    return $this->renderer->renderInIsolation($company_logos);
  }

  /**
   * Sends leads email notifications.
   *
   * @param int $uid
   *   email receiver User ID.
   */
  public function sendLeadsNotification($uid = 0) {
    $query = $this->notificationStorage->getQuery();
    $notification_ids = $query->condition('field_user', $uid)
      ->accessCheck(FALSE)
      ->condition('field_email_status', 2)
      ->condition('type', 'leads')
      ->sort('created', 'ASC')
      ->execute();
    // Continue, if no notification found.
    if (count($notification_ids) === 0) {
      return;
    }
    $formatted_notifications = [];
    $notification_entities = [];
    foreach ($notification_ids as $notification_id) {
      $pending_notification = $this->entityTypeManager->getStorage('notification')->load($notification_id);
      $notification_entities[] = $pending_notification;
      if (
        $pending_notification->hasField('field_related_technology') &&
        !$pending_notification->get('field_related_technology')->isEmpty() &&
        $pending_notification->get('field_related_technology')->entity instanceof NodeInterface &&
        $pending_notification->getOwner() instanceof User
      ) {
        // Group notifications based on technology.
        $tech_node = $pending_notification->get('field_related_technology')->entity;
        $sender = $pending_notification->getOwner();
        $lead_type = 'view';
        if (
          $pending_notification->hasField('field_lead_type') &&
          $pending_notification->get('field_lead_type')->isEmpty()
        ) {
          $lead_type = $pending_notification->hasField('field_lead_type')->value;
        }
        $lead_type = $pending_notification->get('field_lead_type')->value;
        $formatted_notifications[$tech_node->id()][$sender->id()][$lead_type][] = $pending_notification;
      }
    }

    if ($formatted_notifications == []) {
      return;
    }

    // Send Emails.
    $receiver = $this->userStorage->load($uid);
    $user_mail = $receiver->getEmail();
    $params = [
      'subject' => $this->t('You have new or active Leads'),
    ];
    $receiver_host = $this->domainHelper->getUserDomainPath($receiver);
    $params['host'] = $receiver_host;
    // Start body content.
    $body = $this->startBodyContentForLeads($receiver);

    // Check if receiver is having specific module
    // If supplier is having follower and viewer modules then only show user
    // detailed message else show only company name.
    $active_modules = $this->subscriptionPackage->getSupplierActiveModules(TRUE, $receiver);
    if (!array_diff(['recurring_viewers', 'supplier_followers'], $active_modules)) {
      // Show message cards.
      $pro_access = FALSE;
      if (in_array('access_pro_leads', $active_modules, TRUE)) {
        $pro_access = TRUE;
      }
      $body[] = $this->buildBodyWithMessageCards($formatted_notifications, $receiver, $receiver_host, $pro_access);
    }
    else {
      // Show only company logos.
      $body[] = $this->buildBodyWithCompanyLogos($formatted_notifications, $receiver, $receiver_host);
    }
    // Add end body contents.
    $this->endBodyContent($body);
    $params['footer'] = $this->getMailFooter($receiver, $receiver_host);
    // Pass mail content.
    $params['body'] = $body;
    // Send mail.
    $this->triggerEmails($params, $user_mail, $notification_entities);
  }

  /**
   * Get mail footer.
   */
  public function getMailFooter(User $receiver, string $receiver_host) {
    $footer_content = [];

    $notification_settings_url = Url::fromRoute('dm_toolbox.toolbox.redirect', [
      'user' => $receiver->id(),
      'fragment' => 'notification_center',
    ],
    [
      'query' => [
        'open_settings' => 1,
      ],
    ])->toString();

    $login_with_setting_url = Url::fromRoute('user.login', [], [
      'query' => [
        'destination' => $notification_settings_url,
      ],
    ])->toString();

    $footer_content['notification_settings_url'] = $receiver_host . $login_with_setting_url;
    $footer_content['contact_link'] = 'mailto:support@technologycatalogue.com';

    $unsubscribe_message_raw = $this->configFactory->get('dm_general.sitegeneralsettings')->get('mail_unsubscribe_note');
    $unsubscribe_message = $unsubscribe_message_raw['value'];
    $unsubscribe_message = str_replace(':notification_settings_link', $footer_content['notification_settings_url'], $unsubscribe_message);

    $footer_content['unsubscribe'] = $unsubscribe_message;

    $footer_build = [
      '#theme' => 'notification_footer',
      '#content' => $footer_content,
    ];

    return $this->renderer->renderInIsolation($footer_build);
  }

  /**
   * Sends challenge created email notifications.
   *
   * @param int $uid
   *   User ID.
   */
  public function sendChallengeNotification($uid = 0) {
    $challenge_notifications = $this->notificationStorage->loadByProperties([
      'field_user' => $uid,
      'field_email_status' => 2,
      'type' => 'challenge',
    ]);

    // Continue, if no notification found.
    if (count($challenge_notifications) === 0) {
      return;
    }

    $user_notifications = [];

    foreach ($challenge_notifications as $pending_notification) {
      $link = 0;
      /** @var \Drupal\dm_notification\Entity\Notification $pending_notification **/
      if ($pending_notification->hasField('field_related_challenge') && $pending_notification->get('field_related_challenge')->entity instanceof NodeInterface) {
        $link = $pending_notification->get('field_related_challenge')->entity->id();
      }

      // Update only when technology is found.
      /** @var \Drupal\user\Entity\User $notification_owner **/
      $notification_owner = $pending_notification->getOwner();
      $user_notifications[$link]['company_name'] = $this->t('No company assigned');

      // Update with owner company.
      if (
        $notification_owner instanceof UserInterface &&
        $notification_owner->hasField('field_company') &&
        $notification_owner->get('field_company')->entity instanceof Company
      ) {
        /** @var \Drupal\dm_company\Entity\Company $user_company **/
        $user_company = $notification_owner->get('field_company')->entity;
        $user_notifications[$link]['company_name'] = $user_company->getName();
      }

      // Add technology name.
      if ($pending_notification->hasField('field_related_challenge') && $pending_notification->get('field_related_challenge')->entity instanceof NodeInterface) {
        $related_challenge = $pending_notification->get('field_related_challenge')->entity;
        // Challenge Link.
        $ch_link = Url::fromRoute('user.login', [], [
          'query' => [
            'destination' => $related_challenge->toUrl()->toString(),
          ],
        ])->toString();

        $user_notifications[$link]['challenge_name'] = $related_challenge->label();
        $user_notifications[$link]['challenge_link'] = $ch_link;
      }
    }

    // Send Emails.
    if (count($user_notifications) > 0) {
      $user_obj = $this->userStorage->load($uid);
      $user_mail = $user_obj->getEmail();
      // Notification user host.
      $user_host = $this->domainHelper->getUserDomainPath($user_obj);
      $params = [
        'subject' => $this->t('There were new challenges created related to your technologies on :date', [
          ':date' => date("F j, Y"),
        ]),
      ];
      $params['host'] = $user_host;

      // Start body content.
      $body = $this->startBodyContent($user_obj);

      // Sub-Heading.
      $body[] = $this->t('<div class="heading"><h3>Recently created Challenges</h3></div>');
      foreach ($user_notifications as $notification) {
        $body[] = $this->t('<div class="notification-row"><p>"<a href=":host:challenge_link" title=":challenge_name">:challenge_name</a> challenge from :company_name has been created" </p></div>', [
          ':company_name' => $notification['company_name'],
          ':challenge_name' => $notification['challenge_name'] ?? 'No Challenge',
          ':challenge_link' => $notification['challenge_link'] ?? '',
          ':host' => $user_host,
        ]);
      }

      // Add end body contents.
      $this->endBodyContent($body);
      $params['footer'] = $this->getMailFooter($user_obj, $user_host);
      // Pass mail content.
      $params['body'] = $body;

      // Send mail.
      $this->triggerEmails($params, $user_mail, $challenge_notifications);
    }
  }

  /**
   * Sends challenge created email notifications.
   *
   * @param int $uid
   *   User ID.
   */
  public function sendSolutionNotification($uid = 0) {
    $solution_notifications = $this->notificationStorage->loadByProperties([
      'field_user' => $uid,
      'field_email_status' => 2,
      'type' => 'solution',
    ]);

    // Continue, if no notification found.
    if (count($solution_notifications) === 0) {
      return;
    }

    $user_notifications = [];

    foreach ($solution_notifications as $pending_notification) {
      $link = 0;
      /** @var \Drupal\dm_notification\Entity\Notification $pending_notification **/
      if ($pending_notification->hasField('field_related_solution') && $pending_notification->get('field_related_solution')->entity instanceof SolutionEntity) {
        $link = $pending_notification->get('field_related_solution')->entity->id();
      }

      // Update only when technology is found.
      /** @var \Drupal\user\Entity\User $notification_owner **/
      $notification_owner = $pending_notification->getOwner();
      $user_notifications[$link]['company_name'] = $this->t('No company assigned');

      // Update with owner company.
      if (
        $notification_owner instanceof UserInterface &&
        $notification_owner->hasField('field_company') &&
        $notification_owner->get('field_company')->entity instanceof Company
      ) {
        /** @var \Drupal\dm_company\Entity\Company $user_company **/
        $user_company = $notification_owner->get('field_company')->entity;
        $user_notifications[$link]['company_name'] = $user_company->getName();
      }

      // Add technology name.
      if ($pending_notification->hasField('field_related_solution') && $pending_notification->get('field_related_solution')->entity instanceof SolutionEntity) {
        /** @var \Drupal\dm_challenge\Entity\SolutionEntity $related_solution **/
        $related_solution = $pending_notification->get('field_related_solution')->entity;
        if ($related_solution->hasField('field_challenge') && $related_solution->get('field_challenge')->entity instanceof NodeInterface) {
          $challenge = $related_solution->get('field_challenge')->entity;
          $challenge_id = $challenge->id();
          // Solution Url.
          $solution_url = Url::fromRoute('dm_toolbox.toolbox.redirect', [
            'user' => $uid,
            'fragment' => 'my_challenges',
          ], [
            'query' => [
              'challenge_id' => $challenge_id,
            ],
          ]);

          // Challenge Link.
          $solution_link = Url::fromRoute('user.login', [], [
            'query' => [
              'destination' => $solution_url->toString(),
            ],
          ])->toString();

          $solution_name = $related_solution->label();

          // Update with existing tech title, if found.
          if ($related_solution->hasField('field_existing_solution') && !$related_solution->get('field_existing_solution')->isEmpty() && $existing_tech = $related_solution->get('field_existing_solution')->entity) {
            $solution_name = $existing_tech->label();
          }

          // Generate content.
          $user_notifications[$link]['solution_challenge_name'] = $challenge->label();
          $user_notifications[$link]['solution_link'] = $solution_link;
          $user_notifications[$link]['solution_name'] = $solution_name;
        }
      }
    }

    // Send Emails.
    if (count($user_notifications) > 0) {
      $user_obj = $this->userStorage->load($uid);
      $user_mail = $user_obj->getEmail();
      // Notification user host.
      $user_host = $this->domainHelper->getUserDomainPath($user_obj);
      $params = [
        'subject' => $this->t('A new solution has been submitted to your challenge.'),
      ];
      $params['host'] = $user_host;

      foreach ($user_notifications as $notification) {
        // Start body content.
        $body = $this->startBodyContent($user_obj);

        // Sub-Heading.
        $body[] = $this->t('<div class="heading"><h3>Solution submitted for Challenge</h3></div>');
        $body[] = $this->t('<div class="notification-row"><p>":solution_name was submitted for :challenge_name"</p><p>To view the solution, click <a href=":host:solution_link" title=":solution_name">here</a></p></div>', [
          ':solution_name' => $notification['solution_name'] ?? 'No Solution',
          ':challenge_name' => $notification['solution_challenge_name'] ?? 'No Challenge',
          ':host' => $user_host,
          ':solution_link' => $notification['solution_link'],
        ]);

        // Add end body contents.
        $this->endBodyContent($body);
        $params['footer'] = $this->getMailFooter($user_obj, $user_host);
        // Pass mail content.
        $params['body'] = $body;
        // Send mail.
        $this->triggerEmails($params, $user_mail, $solution_notifications);
      }
    }
  }

  /**
   * Start preparing notification body content for leads notification.
   *
   * @param \Drupal\user\Entity\User $user_obj
   *   User ID.
   *
   * @return array
   *   Body content array.
   */
  protected function startBodyContentForLeads($user_obj) {
    $body = [];

    // Prepare body.
    $full_name = $this->dmGeneralService->resolveUsername($user_obj, TRUE);
    $body[] = $this->t('<p>Dear :fullname,</p>', [
      ':fullname' => $full_name,
    ]);

    $body[] = $this->t('<p>You have new or active leads for your technologies!</p>');

    return $body;
  }

  /**
   * Start preparing notification body content.
   *
   * @param \Drupal\user\Entity\User $user_obj
   *   User ID.
   * @param string $host_url
   *   Url to be used for mails.
   * @param string $mail_key
   *   Mail key for alterations.
   *
   * @return array
   *   Body content array.
   */
  protected function startBodyContent($user_obj, $host_url = 'https://www.technologycatalogue.com', $mail_key = 'default') {
    $body = [];

    // Prepare body.
    $full_name = $this->dmGeneralService->resolveUsername($user_obj, TRUE);
    if ($mail_key == 'tech_update_notification') {
      $body[] = $this->t('<p>Hi :fullname,</p>', [
        ':fullname' => $full_name,
      ]);
      $body[] = $this->t('<p>The following technologies that match your area(s) of interest have been added or edited:</p>');
    }
    else {
      $body[] = $this->t('<p>Dear :fullname,</p>', [
        ':fullname' => $full_name,
      ]);

      $body[] = $this->t('<p>You have received the following new notification(s) in your <a href=":host_url" title="technologycatalogue.com" >technologycatalogue.com</a> inbox:</p>', [
        ':host_url' => $host_url,
      ]);
    }

    return $body;
  }

  /**
   * End notification body content.
   *
   * @param array $body
   *   Content that needs to be modified.
   */
  protected function endBodyContent(&$body) {
    $body[] = $this->t('<p>Kind Regards,<br>Technology Catalogue Team</p>');
  }

  /**
   * Send mails and update statuses.
   *
   * @param array $params
   *   Parameters needed for mails.
   * @param string $user_mail
   *   Receiver email ID.
   * @param array $notifications
   *   List of notifications that needs to be updated.
   * @param string $mail_key
   *   Notification mail sending key (to override swiftmailer template).
   */
  protected function triggerEmails($params, $user_mail, $notifications, $mail_key = 'conversation_notification') {
    $langcode = $this->languageManager->getCurrentLanguage()->getId();
    $email = $this->getTargetEmailId() ?? $user_mail;
    $mail_sent = (bool) $this->mailManager->mail('dm_notification', $mail_key, $email, $langcode, $params, NULL, TRUE);
    // If mail sent then only update notification statuses.
    if ($mail_sent === TRUE) {
      $this->emailSent = TRUE;
      foreach ($notifications as $notification) {
        // Update email flag.
        $notification->set('field_email_status', $this->getNotificationEmailStatusValue());
        $notification->save();
      }
    }
  }

}

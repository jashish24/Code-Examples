<?php

namespace Drupal\dm_notification\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\dm_general\Utility\GeneralBuilderInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Url;
use Drupal\dm_notification\Utility\NotificationManager;

/**
 * Provides a 'Notification' block in header.
 *
 * @Block(
 *  id = "notification_block",
 *  admin_label = @Translation("Notification Header block"),
 * )
 */
class NotificationBlock extends BlockBase implements ContainerFactoryPluginInterface {

  /**
   * Drupal\Core\Session\AccountProxyInterface definition.
   *
   * @var \Drupal\Core\Session\AccountProxyInterface
   */
  private $currentUser;

  /**
   * Drupal\dm_general\Utility\GeneralBuilder definition.
   *
   * @var \Drupal\dm_general\Utility\GeneralBuilderService
   */
  private $generalBuilder;

  /**
   * The entity type manager service.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The notification manager service.
   *
   * @var \Drupal\dm_notification\Utility\NotificationManager
   */
  protected $notificationManager;

  /**
   * Constructs a Block object.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Session\AccountProxyInterface $account_proxy
   *   The account.
   * @param \Drupal\dm_general\Utility\GeneralBuilderInterface $general_builder
   *   The general builder.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\dm_notification\Utility\NotificationManager $notification_manager
   *   The notification manager service.
   */
  public function __construct(
    array $configuration,
    string $plugin_id,
    $plugin_definition,
    AccountProxyInterface $account_proxy,
    GeneralBuilderInterface $general_builder,
    EntityTypeManagerInterface $entity_type_manager,
    NotificationManager $notification_manager
  ) {
    $this->currentUser = $account_proxy;
    $this->generalBuilder = $general_builder;
    $this->entityTypeManager = $entity_type_manager;
    $this->notificationManager = $notification_manager;
    parent::__construct($configuration, $plugin_id, $plugin_definition);
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('current_user'),
      $container->get('dm_general.builder'),
      $container->get('entity_type.manager'),
      $container->get('dm_notification.manager')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getCacheMaxAge() {
    return 0;
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    $build = [];
    $notification_str = '';
    $user = $this->generalBuilder->loadUser($this->currentUser->id());
    $notification_str = $this->notificationManager->getUnreadNotificationCountToDisplay($user);

    $class = 'uk-visible';
    if ($notification_str == '') {
      $class = 'uk-hidden';
    }
    $view_all = [
      '#type' => 'link',
      '#title' => $this->t('View all notifications'),
      '#url' => Url::fromRoute('dm_toolbox.toolbox.redirect', [
        'user' => $user->id(),
        'fragment' => 'notification_center',
      ]),
      '#attributes' => [
        'class' => [
          'view-all-notifications',
        ],
      ],
    ];

    $mark_all_read = [
      '#type' => 'link',
      '#title' => $this->t('Mark all as read'),
      '#url' => Url::fromRoute('dm_notification.mark-all-read'),
      '#attributes' => [
        'class' => [
          'use-ajax',
          'mark-all-read',
        ],
      ],
    ];

    if ($this->notificationManager->getUnreadNotificationCountForUser($user) === 0) {
      $mark_all_read['#attributes']['class'][] = 'uk-hidden';
    }

    $build['notification_centre'] = [
      '#type' => 'inline_template',
      '#template' => '
        <button class="n-header-i" type="button">
          <img src="/themes/atom/deploymentmatters/images/toolbox-sidebar-icon/header-notification.svg"/> <span id="notification-count" class="count {{ class }} ">{{ notification_count }}</span>
        </button>
        <div class="notification-header" uk-dropdown="mode: click">
          <div class="title">
            <span>{% trans %} Notification Center {% endtrans %}</span>
            {{ mark_all_read }}
          </div>
          {{ notifications }}
          {{ view_all }}
        </div>',
      '#context' => [
        'notifications' => [
          '#type' => 'view',
          '#name' => 'notifications',
          '#arguments' => [$this->currentUser->id()],
          '#display_id' => 'block_1',
        ],
        'notification_count' => $notification_str,
        'view_all' => $view_all,
        'class' => $class,
        'mark_all_read' => $mark_all_read,
        '#cache' => ['max-age' => 0],
      ],
    ];
    $build['#attached']['library'][] = 'dm_notification/notification_update';
    $build['#attached']['drupalSettings']['unreadNotificationCount'] = $this->notificationManager->getUnreadNotificationCountToDisplay($user);
    $build['#cache'] = ['max-age' => 0];
    return $build;
  }

}

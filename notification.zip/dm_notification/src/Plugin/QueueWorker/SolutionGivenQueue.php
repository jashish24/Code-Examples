<?php

namespace Drupal\dm_notification\Plugin\QueueWorker;

use Drupal\Core\Queue\QueueWorkerBase;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\dm_challenge\Entity\SolutionEntity;

/**
 * Plugin implementation of the solution_given queueworker.
 *
 * @QueueWorker (
 *   id = "solution_given",
 *   title = @Translation("Solution given queue."),
 *   cron = {"time" = 360}
 * )
 */
class SolutionGivenQueue extends QueueWorkerBase {
  use StringTranslationTrait;

  /**
   * {@inheritdoc}
   */
  public function processItem($data) {
    // Process item operations.
    $solution_id = $data['solution_id'];
    $entity_type_manager = \Drupal::entityTypeManager();
    $solution_storage = $entity_type_manager->getStorage('solution');
    $notification_storage = $entity_type_manager->getStorage('notification');

    /** @var \Drupal\dm_challenge\Entity\SolutionEntity $solution **/
    $solution = $solution_storage->load($solution_id);
    if ($solution instanceof SolutionEntity) {
      $solution_label = $solution->label();

      if ($solution->hasField('field_challenge') && !$solution->get('field_challenge')->isEmpty()) {
        /** @var \Drupal\node\Entity\Node $parent_challenge **/
        $parent_challenge = $solution->get('field_challenge')->entity;
        $challenge_label = $parent_challenge->label();

        // Consider solution creator as message owner.
        $message_owner = $solution->getOwner();

        $member = $parent_challenge->getOwner();
        // Set default email status as unsent.
        $email_status = 2;

        // Create notification.
        /** @var \Drupal\dm_notification\Entity\Notification $notification **/
        $notification = $notification_storage->create([
          'type' => 'solution',
          'name' => $this->t('Check out new solution @solution_label provided to your challenge @challenge_label', [
            '@challenge_label' => html_entity_decode($challenge_label),
            '@solution_label' => html_entity_decode($solution_label),
          ]),
          'field_description' => $this->t('Check out new solution @solution_label provided to your challenge @challenge_label', [
            '@challenge_label' => html_entity_decode($challenge_label),
            '@solution_label' => html_entity_decode($solution_label),
          ]),
          'field_read_status' => FALSE,
          'field_related_solution' => $solution->id(),
          'field_email_status' => $email_status,
          'field_message_details' => $this->t('You might want to check :label solution provided to one of your challenges.', [
            ':label' => $solution_label,
          ]),
          'status' => 1,
        ]);

        $notification->field_user->entity = $member;
        // Set technology owner as notification sender.
        $notification->setOwner($message_owner);
        $notification->save();
      }
    }
  }

}

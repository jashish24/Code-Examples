<?php

namespace Drupal\dm_notification\Plugin\QueueWorker;

use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Queue\QueueWorkerBase;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\dm_company\Entity\Company;
use Drupal\dm_notification\Entity\UserNotificationSettings;
use Drupal\dm_notification\Utility\NotificationManager;
use Drupal\node\NodeInterface;
use Drupal\user\Entity\User;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Processes notification related to technology updates.
 *
 * @QueueWorker (
 *   id = "supplier_leads",
 *   title = @Translation("Supplier Leads Queue"),
 *   cron = {"time" = 360}
 * )
 */
class SupplierLeadsQueue extends QueueWorkerBase implements ContainerFactoryPluginInterface {
  use StringTranslationTrait;

  /**
   * The notification manager service.
   *
   * @var \Drupal\dm_notification\Utility\NotificationManager
   */
  protected $notificationManager;

  /**
   * Constructs a new SupplierLeadsQueue worker.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin ID for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\dm_notification\Utility\NotificationManager $notification_manager
   *   The notification.
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, NotificationManager $notification_manager) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->notificationManager = $notification_manager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('dm_notification.manager')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function processItem($data) {
    $tech_id = $data['nid'];
    $sender_uid = $data['uid'];
    $lead_type = $data['lead_type'];
    $lead_category = $data['lead_category'] ?? 'normal';
    $entity_type_manager = \Drupal::entityTypeManager();
    $node_storage = $entity_type_manager->getStorage('node');
    $user_storage = $entity_type_manager->getStorage('user');
    $notification_storage = $entity_type_manager->getStorage('notification');
    $tech_node = $node_storage->load($tech_id);
    if (!$tech_node instanceof NodeInterface) {
      return;
    }
    $receiver_user = $tech_node->getOwner();
    // Use the company admin as recevier of the notification if present.
    if (
      $tech_node->hasField('field_referenced_company') &&
      $tech_node->get('field_referenced_company')->entity instanceof Company
    ) {
      $company = $tech_node->get('field_referenced_company')->entity;
      // Get company admin.
      $company_admin = $company->getCompanyAdmin();
      if ($company_admin !== NULL) {
        $receiver_user = $company_admin;
      }
    }

    // Before creating notification check if
    // notification present in the system with email unsent status.
    if ($this->isNotificationExist($sender_uid, $receiver_user->id(), $tech_id, 'leads', $lead_type, 2)) {
      return;
    }

    // Skip notification for sender.
    if ($sender_uid === $receiver_user->id()) {
      return;
    }

    // Load member user.
    $sender_user = $user_storage->load($sender_uid);

    // Check if sender and receiver users are vaild users.
    // There is chance that user might have deleted.
    if (
      !$sender_user instanceof User ||
      !$receiver_user instanceof User
    ) {
      return;
    }
    // Set default email status as unsent.
    $email_status = 2;

    // Notificaiton Status (Published/unpublished).
    // This will control if notification is shown to user or not.
    $status = 0;

    /** @var \Drupal\dm_notification_settings\Entity\NotificationSettingEntity $notification_settings **/
    $notification_settings = $this->notificationManager->getNotificationSettingsForUser($receiver_user);
    if (!is_null($notification_settings)) {
      // Email status (to send or not).
      $email_notification_settings = $notification_settings->get('field_lead_email_status')->value;

      // Set email status to switched off.
      $email_status = ($email_notification_settings === UserNotificationSettings::EMAIL_OFF) ? 0 : $email_status;
      // Notification status.
      $status = (bool) $notification_settings->get('field_lead_status')->value;
    }

    $tech_label = $tech_node->label();
    if ($lead_type == 'follow') {
      $lead_type_text = 'follower';
    }
    else {
      $lead_type_text = 'page visitor';
    }

    // Default title.
    $title = $this->t('You have a new lead');

    if ($this->isNotificationExist($sender_uid, $receiver_user->id(), $tech_id, 'leads', $lead_type)) {
      $title = $this->t('New view from one of your leads');
    }
    // Create notification.
    /** @var \Drupal\dm_notification\Entity\Notification $notification **/
    $notification = $notification_storage->create([
      'type' => 'leads',
      'name' => $title,
      'field_description' => $this->t('You have a new lead for technology: @tech_name | @lead_type_text', [
        '@tech_name' => html_entity_decode($tech_label),
        '@lead_type_text' => $lead_type_text,
      ]),
      'field_read_status' => FALSE,
      'field_email_status' => $email_status,
      'field_lead_type' => $lead_type,
      'field_lead_category' => $lead_category,
      'status' => $status,
      'field_related_technology' => $tech_node->id(),
    ]);

    $notification->field_user->entity = $receiver_user;
    // Set technology owner as notification sender.
    $notification->setOwner($sender_user);
    $notification->save();
  }

  /**
   * To avoid duplicate notification check if notification exists.
   *
   * @param int $sender_user_id
   *   Notification sender user id.
   * @param int $receiver_user_id
   *   Notification received user id.
   * @param int $tech_id
   *   The Technology id.
   * @param string $notification_type
   *   The notification type (e.g. leads).
   * @param string $lead_type
   *   The lead type (e.g. view, follow).
   * @param string $email_status
   *   Email status. If null get do not apply email status condiion.
   */
  public function isNotificationExist(int $sender_user_id, int $receiver_user_id, int $tech_id, string $notification_type, string $lead_type, $email_status = NULL) {
    $notifications = [];
    $entity_type_manager = \Drupal::entityTypeManager();
    $query = $entity_type_manager->getStorage('notification')->getQuery();
    $query->condition('field_user', $receiver_user_id)
      ->accessCheck(FALSE)
      ->condition('field_related_technology', $tech_id)
      ->condition('type', $notification_type)
      ->condition('field_lead_type', $lead_type)
      ->condition('user_id', $sender_user_id);
    if ($email_status !== NULL) {
      $query->condition('field_email_status', $email_status);
    }
    $notifications = $query->execute();
    if ($notifications == []) {
      return FALSE;
    }
    return TRUE;
  }

}

<?php

namespace Drupal\dm_notification\Plugin\QueueWorker;

use Drupal\Core\Queue\QueueWorkerBase;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\dm_notification\Entity\UserNotificationSettings;
use Drupal\node\Entity\Node;

/**
 * Queue to send notification related to challenge creation.
 *
 * @QueueWorker (
 *   id = "challenge_created",
 *   title = @Translation("Challenge Creation Queue"),
 *   cron = {"time" = 360}
 * )
 */
class ChallengeCreatedQueue extends QueueWorkerBase {
  use StringTranslationTrait;

  /**
   * {@inheritdoc}
   */
  public function processItem($data) {
    // Process item operations.
    $challenge_id = $data['challenge_id'];
    $entity_type_manager = \Drupal::entityTypeManager();
    $node_storage = $entity_type_manager->getStorage('node');
    $user_storage = $entity_type_manager->getStorage('user');
    $notification_storage = $entity_type_manager->getStorage('notification');

    $challenge = $node_storage->load($challenge_id);

    if (!$challenge instanceof Node) {
      return;
    }

    // Tag fields.
    $tag_fields = [
      'field_core_tech',
      'field_industry',
      'field_location',
      'field_theme_discipline',
    ];

    // Technology tags.
    $tech_tags = [];

    // Consider challenge creator as message owner.
    $message_owner = $challenge->getOwner();
    // Notification Storage.
    $notification_manager = \Drupal::service('dm_notification.manager');

    // Collect each field tags.
    foreach ($tag_fields as $field) {
      if ($challenge->hasField($field) && !$challenge->get($field)->isEmpty()) {
        $field_tags = $challenge->get($field)->getValue();

        foreach ($field_tags as $tag) {
          $tech_tags[] = $tag['target_id'];
        }
      }
    }

    if (count($tech_tags) > 0) {
      // Get tech pages related to all tags.
      $tech_query = $node_storage->getQuery();
      $tech_query->accessCheck(FALSE);
      $tech_query->condition('type', 'product_service');
      $tech_query->condition('status', 1);
      $tech_query->sort('created', 'ASC');

      // Add each field condition.
      $tag_group = $tech_query->orConditionGroup();

      foreach ($tag_fields as $field) {
        $tag_group->condition($field, $tech_tags, 'IN');
      }

      $tech_ids = $tech_query->condition($tag_group)->execute();
      $uids = [];

      foreach ($tech_ids as $tech_id) {
        $tech = $node_storage->load($tech_id);

        if ($tech->hasField('field_referenced_company') && !$tech->get('field_referenced_company')->isEmpty()) {
          $company_id = $tech->get('field_referenced_company')->target_id;

          $user_query = $user_storage->getQuery();
          $user_query->accessCheck(FALSE);
          $user_query->condition('field_company', $company_id);
          $user_query->condition('status', 1);

          $tech_users = $user_query->execute();

          // Add to user list.
          $uids += $tech_users;
        }
      }

      // Create notification for each user.
      foreach ($uids as $uid) {
        $member = $user_storage->load($uid);
        // Set default email status as unsent.
        $email_status = 2;
        // Notificaiton read status.
        $status = 0;

        // Member notification settings.
        /** @var \Drupal\dm_notification_settings\Entity\NotificationSettingEntity $notification_settings **/
        $notification_settings = $notification_manager->getNotificationSettingsForUser($member);

        if (!is_null($notification_settings)) {
          // Email status (to send or not).
          $email_notification_settings = $notification_settings->get('field_challenge_email_status')->value;

          // Set email status to switched off.
          $email_status = ($email_notification_settings === UserNotificationSettings::EMAIL_OFF) ? 0 : $email_status;

          // Notification status.
          $normal_notification_settings = (bool) $notification_settings->get('field_challenge_status')->value;
          // Set notification status to read.
          $status = ($normal_notification_settings === TRUE) ? 1 : $status;
        }

        $challenge_label = $challenge->label();

        // Create notification.
        /** @var \Drupal\dm_notification\Entity\Notification $notification **/
        $notification = $notification_storage->create([
          'type' => 'challenge',
          'name' => $this->t('Check out new challenge @challenge_label', [
            '@challenge_label' => html_entity_decode($challenge_label),
          ]),
          'field_description' => $this->t('Check out new challenge') . ' ' . $challenge_label,
          'field_read_status' => FALSE,
          'field_related_challenge' => $challenge->id(),
          'field_email_status' => $email_status,
          'field_message_details' => $this->t('You might be interested in :label challenge which is recently updated on platform.', [
            ':label' => $challenge_label,
          ]),
          'status' => $status,
        ]);

        $notification->field_user->entity = $member;
        // Set technology owner as notification sender.
        $notification->setOwner($message_owner);
        $notification->save();
      }
    }
  }

}

<?php

namespace Drupal\dm_notification\Plugin\QueueWorker;

use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Queue\QueueWorkerBase;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\dm_notification\Entity\UserNotificationSettings;
use Drupal\node\Entity\Node;
use Drupal\domain_access\DomainAccessManagerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Processes notification related to technology updates.
 *
 * @QueueWorker (
 *   id = "tech_update_notification",
 *   title = @Translation("Tech Update Queue"),
 *   cron = {"time" = 360}
 * )
 */
class TechUpdateNotificationQueue extends QueueWorkerBase implements ContainerFactoryPluginInterface {
  use StringTranslationTrait;


  /**
   * Drupal\Core\Config\ConfigFactory definition.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * Service to get User package details.
   *
   * @var \Drupal\subscription_package\Utility\UserPackageDetails
   */
  protected $userPackage;

  /**
   * Ai service.
   *
   * @var \Drupal\dm_product_service\Service\AiService
   */
  protected $aiService;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    $instance = new static($configuration, $plugin_id, $plugin_definition);
    $instance->configFactory = $container->get('config.factory');
    $instance->userPackage = $container->get('subscription_package.user_package_details');
    $instance->aiService = $container->get('dm_product_service.ai_service');
    return $instance;
  }

  /**
   * {@inheritdoc}
   */
  public function processItem($data) {
    $tech_id = $data['tech_id'];
    $uid = $data['user_id'];
    $entity_type_manager = \Drupal::entityTypeManager();
    $node_storage = $entity_type_manager->getStorage('node');
    $user_storage = $entity_type_manager->getStorage('user');
    $notification_storage = $entity_type_manager->getStorage('notification');

    $tech_node = $node_storage->load($tech_id);
    // Tech node should present in the system.
    // Return from here if tech page is deleted.
    if (!$tech_node instanceof Node) {
      return;
    }
    // Consider current user(editor of technology) as message owner.
    $message_owner = $tech_node->getOwner();
    // Notification Storage.
    $notification_manager = \Drupal::service('dm_notification.manager');

    // Skip notification for sender.
    if ($uid === $message_owner->id()) {
      return;
    }

    // Load member user.
    $member = $user_storage->load($uid);

    // Send only for end user.
    if (is_null($member) || !$member->hasRole('customer')) {
      return;
    }

    // Check if notifications are already created or not.
    $present_notifications = $notification_storage->loadByProperties([
      'field_related_technology' => $tech_node->id(),
      'field_user' => $member->id(),
      'type' => 'technology_update',
      'field_email_status' => 2,
      'field_read_status' => FALSE,
    ]);

    if (count($present_notifications) > 0) {
      return;
    }

    // Check for member domain before creating notification.
    $user_domains = [
      'default',
    ];

    $tech_domains = [
      'default',
    ];

    // Domain access field.
    $domain_access_field = DomainAccessManagerInterface::DOMAIN_ACCESS_FIELD;

    // User domains.
    if ($member->hasField($domain_access_field) && !$member->get($domain_access_field)->isEmpty()) {
      $user_domains = [];
      $domain_list = $member->get($domain_access_field)->getValue();

      foreach ($domain_list as $domain_info) {
        $user_domains[] = $domain_info['target_id'];
      }
    }

    // Tech domains.
    if ($tech_node->hasField($domain_access_field) && !$tech_node->get($domain_access_field)->isEmpty()) {
      $tech_domains = [];
      $domain_list = $tech_node->get($domain_access_field)->getValue();

      foreach ($domain_list as $domain_info) {
        $tech_domains[] = $domain_info['target_id'];
      }
    }

    $allowed_domains = array_intersect($user_domains, $tech_domains);
    $allowed_domains = array_unique($allowed_domains);

    if ($allowed_domains === []) {
      return;
    }

    // Do not processed if user is not having access to Ai technology.
    if (
      $this->aiService->isAiTechnology($tech_node) &&
      !$this->userPackage->isEndUserHasModule($member, 'access_ai_tech_pages')
    ) {
      return;
    }

    // One of user active domain.
    $domain_id = reset($allowed_domains);

    // Set default email status as unsent.
    $email_status = 2;

    // Notificaiton read status.
    $status = 0;

    // Member notification settings.
    /** @var \Drupal\dm_notification_settings\Entity\NotificationSettingEntity $notification_settings **/
    $notification_settings = $notification_manager->getNotificationSettingsForUser($member);

    if (!is_null($notification_settings)) {
      // Email status (to send or not).
      $email_notification_settings = $notification_settings->get('field_technology_email_status')->value;

      // Set email status to switched off.
      $email_status = ($email_notification_settings === UserNotificationSettings::EMAIL_OFF) ? 0 : $email_status;

      // Notification status.
      $normal_notification_settings = (bool) $notification_settings->get('field_technology_update_status')->value;
      // Set notification status to read.
      $status = ($normal_notification_settings === TRUE) ? 1 : $status;
    }

    $tech_label = $tech_node->label();

    // Create notification.
    /** @var \Drupal\dm_notification\Entity\Notification $notification **/
    $notification = $notification_storage->create([
      'type' => 'technology_update',
      'name' => $this->t('Check out @tech_name', [
        '@tech_name' => html_entity_decode($tech_label),
      ]),
      'field_description' => $this->t('Check out') . ' ' . $tech_label,
      'field_read_status' => FALSE,
      'field_link' => $tech_node->toUrl()->toString(),
      'field_email_status' => $email_status,
      'field_message_details' => $this->t('You might be interested in :label technology which is recently updated on platform.', [
        ':label' => $tech_label,
      ]),
      'status' => $status,
      'field_related_technology' => $tech_node->id(),
      'field_domain' => $domain_id,
    ]);

    $notification->field_user->entity = $member;
    // Set technology owner as notification sender.
    $notification->setOwner($message_owner);
    $notification->save();
  }

}

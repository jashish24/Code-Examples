<?php

namespace Drupal\dm_notification;

use Drupal\content_translation\ContentTranslationHandler;

/**
 * Defines the translation handler for notification.
 */
class NotificationTranslationHandler extends ContentTranslationHandler {

  // Override here the needed methods from ContentTranslationHandler.
}

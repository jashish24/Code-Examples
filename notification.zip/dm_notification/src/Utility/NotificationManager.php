<?php

namespace Drupal\dm_notification\Utility;

use Drupal\Core\Ajax\AfterCommand;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Entity\EntityFormBuilderInterface;
use Drupal\Core\Logger\LoggerChannelFactory;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\dm_general\Utility\GeneralBuilderInterface;
use Symfony\Component\HttpFoundation\RequestStack;
use Drupal\user\Entity\User;
use Drupal\Core\Entity\EntityStorageException;
use Drupal\Core\Url;
use Drupal\dm_general\Ajax\RefreshViewCommand;
use Drupal\dm_notification_settings\Entity\NotificationSettingEntityInterface;

/**
 * Class Notification.
 *
 * The notification service.
 */
class NotificationManager {

  use StringTranslationTrait;

  /**
   * The entity type manager service.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * Entity form builder service.
   *
   * @var \Drupal\Core\Form\FormBuilder
   */
  protected $entityFormBuilder;

  /**
   * Drupal\Core\Logger\LoggerChannelInterface definition.
   *
   * @var \Drupal\Core\Logger\LoggerChannelInterface
   */
  protected $logger;

  /**
   * Drupal\Core\Session\AccountProxyInterface definition.
   *
   * @var \Drupal\Core\Session\AccountProxyInterface
   */
  private $currentUser;

  /**
   * Symfony\Component\HttpFoundation\Request definition.
   *
   * @var \Symfony\Component\HttpFoundation\Request|null
   */
  private $currentRequest;

  /**
   * Drupal\dm_general\Utility\GeneralBuilder definition.
   *
   * @var \Drupal\dm_general\Utility\GeneralBuilderService
   */
  private $generalBuilder;

  /**
   * Drupal\Core\Config\ConfigFactory definition.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * Constructs a new NotificationManager object.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\Core\Logger\LoggerChannelFactory $logger_channel_factory
   *   The logger factory.
   * @param \Drupal\Core\Session\AccountProxyInterface $account_proxy
   *   The account.
   * @param \Symfony\Component\HttpFoundation\RequestStack $request_stack
   *   The request stack.
   * @param \Drupal\dm_general\Utility\GeneralBuilderInterface $general_builder
   *   The general builder.
   * @param \Drupal\Core\Entity\EntityFormBuilderInterface $entity_form_builder
   *   Entity form builder service.
   */
  public function __construct(
    EntityTypeManagerInterface $entity_type_manager,
    LoggerChannelFactory $logger_channel_factory,
    AccountProxyInterface $account_proxy,
    RequestStack $request_stack,
    GeneralBuilderInterface $general_builder,
    EntityFormBuilderInterface $entity_form_builder
  ) {
    $this->entityTypeManager = $entity_type_manager;
    $this->logger = $logger_channel_factory->get('dm_notification');
    $this->currentUser = $account_proxy;
    $this->currentRequest = $request_stack->getCurrentRequest();
    $this->generalBuilder = $general_builder;
    $this->entityFormBuilder = $entity_form_builder;
  }

  /**
   * Get the notification view.
   *
   * @return array
   *   Returns the build array.
   */
  public function getNotificationCenter(): array {
    $build = [];
    $user = $this->generalBuilder->loadUser($this->currentUser->id());
    $open_settings = (int) $this->currentRequest->query->get('open_settings');
    $mark_all_read = [
      '#type' => 'link',
      '#title' => $this->t('Mark all as read'),
      '#url' => Url::fromRoute('dm_notification.mark-all-read'),
      '#attributes' => [
        'class' => [
          'mark-as-read',
          'mark-all-read',
          'use-ajax',
        ],
      ],
    ];
    if ($this->getUnreadNotificationCountForUser($user) === 0) {
      $mark_all_read['#attributes']['class'][] = 'uk-hidden';
    }

    $build['notification_centre'] = [
      '#type' => 'inline_template',
      '#template' =>
      '<div class="notification-tab">
          {{ mark_all_read }}
          <ul class="uk-tab" id="notification-tab-ul" uk-switcher>
            <li class="notification-list-tab"><a href="">{% trans %} Notifications {% endtrans %} </a></li>
            <li class="notification-settings-tab {{ open_settings }}"><a href="">{% trans %} Notifications Settings {% endtrans %} </a></li>
          </ul>
          <ul id="notification-tabs" class="uk-switcher uk-margin">
            <li>
              {{ notifications }}
            </li>
            <li>
              {{ notification_settings }}
            </li>
          </ul>
        </div>',
      '#context' => [
        'notifications' => [
          '#type' => 'view',
          '#name' => 'notifications',
          '#arguments' => [$this->currentUser->id()],
          '#display_id' => 'block_1',
        ],
        'notification_settings' => $this->getNotificationSettingsForm(),
        'mark_all_read' => $mark_all_read,
        'open_settings' => ($open_settings === 1) ? 'uk-active' : 'second',
      ],
    ];

    return $build;
  }

  /**
   * Get user notification settings form.
   *
   * @return array
   *   Settings form array.
   */
  public function getNotificationSettingsForm() {
    $user = $this->entityTypeManager->getStorage('user')->load($this->currentUser->id());

    $notification_setting = $this->getNotificationSettingsForUser($user);

    $form = $this->entityFormBuilder->getForm($notification_setting, 'edit');

    // Remove extra access.
    $form['user_id']['#access'] = FALSE;
    $form['name']['#access'] = FALSE;
    $form['revision_information']['#access'] = FALSE;
    $form['status']['#access'] = FALSE;

    // Add Classes.
    $form['#attributes']['class'][] = 'user-notification-settings-form';

    return $form;
  }

  /**
   * Check notification center access.
   *
   * @param \Drupal\user\Entity\User $user
   *   User for which the access has to be checked.
   *
   * @return bool
   *   Returns TRUE or false based on access check.
   */
  public function notificationCenterAccessCheck(User $user) {
    if ($this->currentUser->hasPermission('administer users')) {
      return TRUE;
    }
    // If user is not having permission.
    if (!$this->currentUser->hasPermission('access notification center') || $this->currentUser->id() !== $user->id()) {
      return FALSE;
    }

    return TRUE;
  }

  /**
   * Get notification settings for user.
   *
   * @return Drupal\dm_notification_settings\Entity\NotificationSettingEntity|null
   *   notification settings.
   */
  public function getNotificationSettingsForUser(User $user) {
    $settings = NULL;
    $notification_setting = NULL;
    try {
      $notification_setting_storage = $this->entityTypeManager->getStorage('notification_settings');
      $settings = $notification_setting_storage->loadByProperties(
        ['user_id' => $user->id()]
      );
    }
    catch (EntityStorageException $e) {
      $this->logger->error($e->getMessage());
    }

    if ($settings !== []) {
      $notification_setting = reset($settings);
    }
    else {
      $uid = $user->id();

      $user_notification_settings = [
        'name' => "UID: {$uid} Notification Settings",
        'field_conversation_status' => TRUE,
        'field_challenge_status' => TRUE,
        'field_technology_update_status' => TRUE,
        'field_lead_status' => TRUE,
        'field_conversation_email_status' => NotificationSettingEntityInterface::EMAIL_DAILY,
        'field_challenge_email_status' => NotificationSettingEntityInterface::EMAIL_DAILY,
        'field_technology_email_status' => NotificationSettingEntityInterface::EMAIL_WEEKLY,
        'field_lead_email_status' => NotificationSettingEntityInterface::EMAIL_WEEKLY,
        'user_id' => $uid,
      ];

      $notification_setting = $notification_setting_storage
        ->create($user_notification_settings);

      $notification_setting->save();
    }

    return $notification_setting;
  }

  /**
   * Get unread notification count for user.
   *
   * @return int
   *   Unread notification count.
   */
  public function getUnreadNotificationCountForUser(User $user) {
    $count = 0;
    $notifications = [];
    $notifications = $this->getUnreadNotificationsForUser($user);
    if ($notifications !== []) {
      $count = count($notifications);
    }
    return $count;
  }

  /**
   * Get unread notification count for user.
   *
   * @return int
   *   Unread notification count.
   */
  public function getUnreadNotificationCountToDisplay(User $user) {
    $count_str = 0;
    $count = $this->getUnreadNotificationCountForUser($user);
    $count_str = $count;
    if ($count == 0) {
      $count_str = '';
    }
    if ($count > 5) {
      $count_str = $this->t('+5');
    }
    return $count_str;
  }

  /**
   * Get unread notifications for user.
   *
   * @return array
   *   Array of Unread notifications.
   */
  public function getUnreadNotificationsForUser(User $user) {
    $notifications = [];
    try {
      $notifications = $this->entityTypeManager->getStorage('notification')->loadByProperties(
        [
          'field_user' => $user->id(),
          'field_read_status' => FALSE,
          'status' => 1,
        ]
      );
    }
    catch (EntityStorageException $e) {
      $this->logger->error($e->getMessage());
    }
    return $notifications;
  }

  /**
   * Get notification Ajax response.
   *
   * @return \Drupal\Core\Ajax\AjaxResponse
   *   Ajax response to refresh the view.
   */
  public function getNotificationAjaxResponse(AjaxResponse $response = NULL) {
    $user = $this->generalBuilder->loadUser($this->currentUser->id());
    if ($response === NULL) {
      $response = new AjaxResponse();
    }
    $build = [];
    $build['#attached']['library'][] = 'dm_general/refresh_view';
    $build['#attached']['drupalSettings']['unreadNotificationCount'] = $this->getUnreadNotificationCountToDisplay($user);
    $response->addCommand(new AfterCommand('.view-notifications', $build));
    $response->addCommand(new RefreshViewCommand('.view-notifications'));
    return $response;
  }

}

<?php

namespace Drupal\dm_notification\Controller;

use Drupal\Component\Utility\Xss;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\CloseModalDialogCommand;
use Drupal\Core\Ajax\OpenModalDialogCommand;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Drupal\Core\Entity\EntityStorageException;
use Drupal\Core\Url;
use Drupal\Core\Link;
use Drupal\dm_notification\Entity\NotificationInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\dm_notification_settings\Entity\NotificationSettingEntity;
use Drupal\dm_notification_settings\Entity\NotificationSettingEntityInterface;

/**
 * Class NotificationController.
 *
 *  Returns responses for Notification routes.
 */
class NotificationController extends ControllerBase implements ContainerInjectionInterface {

  /**
   * The date formatter.
   *
   * @var \Drupal\Core\Datetime\DateFormatter
   */
  protected $dateFormatter;

  /**
   * The renderer.
   *
   * @var \Drupal\Core\Render\Renderer
   */
  protected $renderer;

  /**
   * Drupal\Core\Logger\LoggerChannelInterface definition.
   *
   * @var \Drupal\Core\Logger\LoggerChannelInterface
   */
  protected $logger;

  /**
   * Drupal\dm_general\Utility\GeneralBuilderService definition.
   *
   * @var \Drupal\dm_general\Utility\GeneralBuilderService
   */
  protected $generalBuilder;

  /**
   * Drupal\dm_general\Utility\GeneralBuilderService definition.
   *
   * @var \Drupal\dm_notification\Utility\NotificationManager
   */
  protected $notificationManager;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    $instance = parent::create($container);
    $instance->dateFormatter = $container->get('date.formatter');
    $instance->renderer = $container->get('renderer');
    $instance->logger = $container->get('logger.factory')->get('dm_notification');
    $instance->generalBuilder = $container->get('dm_general.builder');
    $instance->notificationManager = $container->get('dm_notification.manager');
    return $instance;
  }

  /**
   * Displays a Notification revision.
   *
   * @param int $notification_revision
   *   The Notification revision ID.
   *
   * @return array
   *   An array suitable for drupal_render().
   */
  public function revisionShow($notification_revision) {
    /** @var \Drupal\Core\Entity\RevisionableStorageInterface **/
    $notification_storage = $this->entityTypeManager()->getStorage('notification');
    $notification = $notification_storage
      ->loadRevision($notification_revision);
    $view_builder = $this->entityTypeManager()->getViewBuilder('notification');

    return $view_builder->view($notification);
  }

  /**
   * Page title callback for a Notification revision.
   *
   * @param int $notification_revision
   *   The Notification revision ID.
   *
   * @return string
   *   The page title.
   */
  public function revisionPageTitle($notification_revision) {
    /** @var \Drupal\Core\Entity\RevisionableStorageInterface **/
    $notification_storage = $this->entityTypeManager()->getStorage('notification');
    /** @var \Drupal\dm_notification\Entity\Notification **/
    $notification = $notification_storage
      ->loadRevision($notification_revision);
    return $this->t('Revision of %title from %date', [
      '%title' => $notification->label(),
      '%date' => $this->dateFormatter->format($notification->getRevisionCreationTime()),
    ]);
  }

  /**
   * Generates an overview table of older revisions of a Notification.
   *
   * @param \Drupal\dm_notification\Entity\NotificationInterface $notification
   *   A Notification object.
   *
   * @return array
   *   An array as expected by drupal_render().
   */
  public function revisionOverview(NotificationInterface $notification) {
    $account = $this->currentUser();

    /** @var \Drupal\dm_notification\NotificationStorage **/
    $notification_storage = $this->entityTypeManager()->getStorage('notification');

    $langcode = $notification->language()->getId();
    $langname = $notification->language()->getName();
    $languages = $notification->getTranslationLanguages();
    $has_translations = (count($languages) > 1);
    $build = [];
    $build['#title'] = $has_translations ? $this->t('@langname revisions for %title', [
      '@langname' => $langname,
      '%title' => $notification->label(),
    ]) : $this->t('Revisions for %title', [
      '%title' => $notification->label(),
    ]);

    $header = [$this->t('Revision'), $this->t('Operations')];
    $revert_permission = (($account->hasPermission("revert all notification revisions") || $account->hasPermission('administer notification entities')));
    $delete_permission = (($account->hasPermission("delete all notification revisions") || $account->hasPermission('administer notification entities')));

    $rows = [];

    $vids = $notification_storage->revisionIds($notification);

    $latest_revision = TRUE;

    foreach (array_reverse($vids) as $vid) {
      /** @var \Drupal\dm_notification\Entity\Notification $revision **/
      $revision = $notification_storage->loadRevision($vid);
      // Only show revisions that are affected by the language that is being
      // displayed.
      if ($revision->hasTranslation($langcode) && $revision->getTranslation($langcode)->isRevisionTranslationAffected()) {
        $username = [
          '#theme' => 'username',
          '#account' => $revision->getRevisionUser(),
        ];

        // Use revision link to link to revisions that are not active.
        $date = $this->dateFormatter->format($revision->getRevisionCreationTime(), 'short');
        if ($vid != $notification->getRevisionId()) {
          $link = Link::fromTextAndUrl($date, new Url('entity.notification.revision', [
            'notification' => $notification->id(),
            'notification_revision' => $vid,
          ]));
        }
        else {
          $link = $notification->toLink($date)->toString();
        }

        $row = [];
        $column = [
          'data' => [
            '#type' => 'inline_template',
            '#template' => '{% trans %}{{ date }} by {{ username }}{% endtrans %}{% if message %}<p class="revision-log">{{ message }}</p>{% endif %}',
            '#context' => [
              'date' => $link,
              'username' => $this->renderer->renderInIsolation($username),
              'message' => [
                '#markup' => $revision->getRevisionLogMessage(),
                '#allowed_tags' => Xss::getHtmlTagList(),
              ],
            ],
          ],
        ];
        $row[] = $column;

        if ($latest_revision) {
          $row[] = [
            'data' => [
              '#prefix' => '<em>',
              '#markup' => $this->t('Current revision'),
              '#suffix' => '</em>',
            ],
          ];
          foreach ($row as &$current) {
            $current['class'] = ['revision-current'];
          }
          $latest_revision = FALSE;
        }
        else {
          $links = [];
          if ($revert_permission) {
            $links['revert'] = [
              'title' => $this->t('Revert'),
              'url' => $has_translations ?
              Url::fromRoute('entity.notification.translation_revert', [
                'notification' => $notification->id(),
                'notification_revision' => $vid,
                'langcode' => $langcode,
              ]) :
              Url::fromRoute('entity.notification.revision_revert', [
                'notification' => $notification->id(),
                'notification_revision' => $vid,
              ]),
            ];
          }

          if ($delete_permission) {
            $links['delete'] = [
              'title' => $this->t('Delete'),
              'url' => Url::fromRoute('entity.notification.revision_delete', [
                'notification' => $notification->id(),
                'notification_revision' => $vid,
              ]),
            ];
          }

          $row[] = [
            'data' => [
              '#type' => 'operations',
              '#links' => $links,
            ],
          ];
        }

        $rows[] = $row;
      }
    }

    $build['notification_revisions_table'] = [
      '#theme' => 'table',
      '#rows' => $rows,
      '#header' => $header,
    ];

    return $build;
  }

  /**
   * Mark notification as read.
   *
   * @param \Drupal\dm_notification\Entity\NotificationInterface $notification
   *   The Notification.
   * @param int $status
   *   Notification read status.
   *
   * @return \Drupal\Core\Ajax\AjaxResponse
   *   Ajax response to refresh the view.
   */
  public function changeNotificationReadStatus(NotificationInterface $notification, int $status) {
    try {
      if (
        $notification->hasField('field_read_status')
      ) {
        $notification->set('field_read_status', (bool) $status);
        $notification->save();
      }
    }
    catch (EntityStorageException $e) {
      $this->logger->error($e->getMessage());
    }
    $response = $this->notificationManager->getNotificationAjaxResponse();
    return $response;
  }

  /**
   * Mark all notification as read.
   *
   * @return \Drupal\Core\Ajax\AjaxResponse
   *   Ajax response to refresh the view.
   */
  public function markAllNotificationsToRead() {
    $response = new AjaxResponse();
    $user = $this->generalBuilder->loadUser($this->currentUser()->id());
    $notifications = $this->notificationManager->getUnreadNotificationsForUser($user);
    if ($notifications === []) {
      return $response;
    }
    try {
      foreach ($notifications as $notification) {
        $notification->set('field_read_status', TRUE);
        $notification->save();
      }
    }
    catch (EntityStorageException $e) {
      $this->logger->error($e->getMessage());
    }

    $response = $this->notificationManager->getNotificationAjaxResponse($response);
    return $response;
  }

  /**
   * Delete the notification.
   *
   * @param \Drupal\dm_notification\Entity\NotificationInterface $notification
   *   The Notification.
   *
   * @return \Drupal\Core\Ajax\AjaxResponse
   *   Ajax response to refresh the view
   */
  public function notificationDelete(NotificationInterface $notification) {
    try {
      $notification->delete();
    }
    catch (EntityStorageException $e) {
      $this->logger->error($e->getMessage());
    }
    $response = new AjaxResponse();
    $response->addCommand(new CloseModalDialogCommand());
    $response = $this->notificationManager->getNotificationAjaxResponse($response);

    return $response;
  }

  /**
   * Delete the notification.
   *
   * @param \Drupal\dm_notification\Entity\NotificationInterface $notification
   *   The Notification.
   *
   * @return \Drupal\Core\Ajax\AjaxResponse
   *   Ajax response to refresh the view
   */
  public function turnOffNotificationLikeThis(NotificationInterface $notification) {
    try {
      $type = $notification->bundle();
      $user = $this->generalBuilder->loadUser($this->currentUser()->id());
      $settings = $this->notificationManager->getNotificationSettingsForUser($user);
      if ($settings instanceof NotificationSettingEntity) {
        $field = NotificationSettingEntityInterface::FIELD_BUNDLE_MAPPING[$type];
        if ($settings->hasField($field)) {
          $settings->set($field, FALSE);
          $settings->save();
        }
      }
      $notification->delete();
    }
    catch (EntityStorageException $e) {
      $this->logger->error($e->getMessage());
    }
    $response = $this->notificationManager->getNotificationAjaxResponse();

    return $response;
  }

  /**
   * Pin the notification.
   *
   * @param \Drupal\dm_notification\Entity\NotificationInterface $notification
   *   The Notification.
   * @param int $status
   *   The pin status to apply.
   *
   * @return \Drupal\Core\Ajax\AjaxResponse
   *   Ajax response to refresh the view.
   */
  public function changeNotificationPinStatus(NotificationInterface $notification, int $status) {
    try {
      if (
        $notification->hasField('sticky')
      ) {
        $notification->set('sticky', (bool) $status);
        $notification->save();
      }
    }
    catch (EntityStorageException $e) {
      $this->logger->error($e->getMessage());
    }
    $response = $this->notificationManager->getNotificationAjaxResponse();
    return $response;
  }

  /**
   * Notification delete confirmation.
   *
   * @param \Drupal\dm_notification\Entity\NotificationInterface $notification
   *   The Notification.
   *
   * @return \Drupal\Core\Ajax\AjaxResponse
   *   Ajax response to refresh the view.
   */
  public function notificationDeleteConfirmation(NotificationInterface $notification) {
    $response = new AjaxResponse();
    $build = [];
    $build['wrapper'] = $this->generalBuilder->buildContainer(['class' => ['notification-delete-confirmation uk-text-center']]);
    $build['wrapper']['message'] = $this->generalBuilder->buildHtmlElement('p', $this->t('Are you sure you want to delete the notification?'), ['class' => ['uk-text-center']]);
    $build['wrapper']['wrap_1'] = $this->generalBuilder->buildContainer(['class' => ['uk-text-center']]);
    $build['wrapper']['wrap_1']['button_no'] = $this->generalBuilder->buildLinkElement(
        $this->t('No'),
        Url::fromRoute('dm_general.close_modal'),
        ['button', 'btn-secondary' , 'close-modal', 'use-ajax']
      );
    $build['wrapper']['wrap_1']['button_yes'] = $this->generalBuilder->buildLinkElement(
        $this->t('Yes'),
        Url::fromRoute('dm_notification.delete',
        [
          'notification' => $notification->id(),
        ]),
        ['button', 'use-ajax']
      );
    $response->addCommand(
      new OpenModalDialogCommand(
        '',
        $build,
        [
          'width' => '400',
          'dialogClass' => 'notification-delete-confirm',
        ]
      )
    );
    return $response;
  }

}

<?php

namespace Drupal\dm_notification\Access;

use Drupal\Core\Routing\Access\AccessInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Access\AccessResult;
use Drupal\Core\Routing\CurrentRouteMatch;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\user\Entity\User;

/**
 * Checks access to perform notification operations.
 */
class NotificationAccessCheck implements AccessInterface {
  /**
   * Drupal\Core\Routing\CurrentRouteMatch definition.
   *
   * @var \Drupal\Core\Routing\CurrentRouteMatch
   */
  protected $currentRouteMatch;

  /**
   * Account Proxy to fetch the current user.
   *
   * @var \Drupal\Core\Session\AccountProxyInterface
   */
  protected $accountProxy;

  /**
   * Constructs a new LinkInParameter object.
   *
   * @param \Drupal\Core\Session\AccountProxyInterface $account_proxy
   *   The account proxy to fetch the current user.
   * @param \Drupal\Core\Routing\CurrentRouteMatch $current_route_match
   *   The current route match.
   */
  public function __construct(AccountProxyInterface $account_proxy, CurrentRouteMatch $current_route_match) {
    $this->accountProxy = $account_proxy;
    $this->currentRouteMatch = $current_route_match;
  }

  /**
   * A notification access check.
   *
   * @param \Drupal\Core\Session\AccountInterface $account
   *   Run access checks for this account.
   *
   * @return \Drupal\Core\Access\AccessResultInterface
   *   The access result.
   */
  public function access(AccountInterface $account) {
    $notification = $this->currentRouteMatch->getParameter('notification');
    if (
      $notification->hasField('field_user') &&
      !$notification->get('field_user')->isEmpty()
    ) {
      $authored_for = $notification->get('field_user')->entity;
      if ($authored_for instanceof User &&
        $account->id() === $authored_for->id()
      ) {
        return AccessResult::allowed();
      }
    }
    return AccessResult::forbidden();
  }

}

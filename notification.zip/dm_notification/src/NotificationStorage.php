<?php

namespace Drupal\dm_notification;

use Drupal\Core\Entity\Sql\SqlContentEntityStorage;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Language\LanguageInterface;
use Drupal\dm_notification\Entity\NotificationInterface;

/**
 * Defines the storage handler class for Notification entities.
 *
 * This extends the base storage class, adding required special handling for
 * Notification entities.
 *
 * @ingroup dm_notification
 */
class NotificationStorage extends SqlContentEntityStorage implements NotificationStorageInterface {

  /**
   * {@inheritdoc}
   */
  public function revisionIds(NotificationInterface $entity) {
    return $this->database->query(
      'SELECT vid FROM {notification_revision} WHERE id=:id ORDER BY vid',
      [':id' => $entity->id()]
    )->fetchCol();
  }

  /**
   * {@inheritdoc}
   */
  public function userRevisionIds(AccountInterface $account) {
    return $this->database->query(
      'SELECT vid FROM {notification_field_revision} WHERE uid = :uid ORDER BY vid',
      [':uid' => $account->id()]
    )->fetchCol();
  }

  /**
   * {@inheritdoc}
   */
  public function countDefaultLanguageRevisions(NotificationInterface $entity) {
    return $this->database->query('SELECT COUNT(*) FROM {notification_field_revision} WHERE id = :id AND default_langcode = 1', [':id' => $entity->id()])
      ->fetchField();
  }

  /**
   * {@inheritdoc}
   */
  public function clearRevisionsLanguage(LanguageInterface $language) {
    return $this->database->update('notification_revision')
      ->fields(['langcode' => LanguageInterface::LANGCODE_NOT_SPECIFIED])
      ->condition('langcode', $language->getId())
      ->execute();
  }

}
